from __future__ import annotations


def _contains(values, wanted: str) -> bool:
    wanted = str(wanted).casefold()
    return any(str(value).casefold() == wanted for value in (values or []))


def matches_full_filter(item: dict, filter_spec: dict | None) -> bool:
    spec = filter_spec or {}
    genre = spec.get("genre")
    if genre and not _contains(item.get("genres"), genre):
        return False
    tag = spec.get("tag")
    if tag and not _contains(item.get("tags"), tag):
        return False
    tags_any = [str(x) for x in (spec.get("tags_any") or [])]
    if tags_any and not any(_contains(item.get("tags"), wanted) for wanted in tags_any):
        return False
    year = item.get("year")
    year_min = spec.get("year_min")
    year_max = spec.get("year_max")
    if year_min is not None and (year is None or int(year) < int(year_min)):
        return False
    if year_max is not None and (year is None or int(year) > int(year_max)):
        return False
    keywords = [str(x).casefold() for x in (spec.get("title_keywords") or []) if str(x).strip()]
    title = str(item.get("title") or "").casefold()
    if keywords and not all(keyword in title for keyword in keywords):
        return False
    item_ids = {str(x) for x in (spec.get("item_ids") or [])}
    if item_ids and str(item.get("jellyfin_item_id") or "") not in item_ids:
        return False
    return True
