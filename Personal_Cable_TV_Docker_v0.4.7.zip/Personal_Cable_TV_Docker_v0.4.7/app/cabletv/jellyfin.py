from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from typing import Callable


def _normalize(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()


def _default_fetch(url: str, headers: dict[str, str]) -> dict:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


class JellyfinMetadataImporter:
    """Read metadata from Jellyfin; this class never writes to Jellyfin."""

    def __init__(self, db, fetch_json: Callable[[str, dict[str, str]], dict] | None = None):
        self.db = db
        self.fetch_json = fetch_json or _default_fetch

    def import_metadata(self, base_url: str, api_key: str) -> dict[str, int]:
        base = base_url.rstrip("/")
        params = urllib.parse.urlencode({
            "Recursive": "true",
            "IncludeItemTypes": "Movie,Episode",
            "Fields": "Genres,Tags,Path,Studios",
            "EnableImages": "false",
            "EnableUserData": "false",
        })
        url = f"{base}/Items?{params}"
        payload = self.fetch_json(url, {"X-Emby-Token": api_key, "Accept": "application/json"})
        remote_items = payload.get("Items", [])

        locals_by_key: dict[tuple[str, int | None], list[dict]] = {}
        locals_by_path_tail: dict[str, list[dict]] = {}
        for item in self.db.list_media():
            locals_by_key.setdefault((_normalize(item["title"]), item.get("year")), []).append(item)
            tail = item["path"].replace("\\", "/").split("/")[-1].casefold()
            locals_by_path_tail.setdefault(tail, []).append(item)

        matched = 0
        for remote in remote_items:
            name = remote.get("Name") or ""
            year = remote.get("ProductionYear")
            candidates = locals_by_key.get((_normalize(name), year), [])
            if not candidates and year is None:
                # Fall back to title-only matching when Jellyfin lacks a year.
                title_norm = _normalize(name)
                candidates = [i for (t, _), vals in locals_by_key.items() if t == title_norm for i in vals]
            if not candidates and remote.get("Path"):
                tail = str(remote["Path"]).replace("\\", "/").split("/")[-1].casefold()
                candidates = locals_by_path_tail.get(tail, [])
            if len(candidates) != 1:
                continue
            local = candidates[0]
            genres = set(local.get("genres") or []) | set(remote.get("Genres") or [])
            tags = set(local.get("tags") or []) | set(remote.get("Tags") or [])
            studio_names = [str(s.get("Name", "")) for s in remote.get("Studios") or [] if isinstance(s, dict)]
            combined = " ".join([name, *studio_names, *list(tags)]).casefold()
            if "marvel" in combined:
                tags.add("Marvel")
            if "dc " in combined or "dc studios" in combined or "dc comics" in combined:
                tags.add("DC")
            if "christmas" in combined or "xmas" in combined:
                tags.add("Christmas")
            self.db.update_media_metadata(local["id"], sorted(genres), sorted(tags), year)
            matched += 1

        return {"remote": len(remote_items), "matched": matched}


class JellyfinClient:
    """Small GET-only Jellyfin client used by Full Library Mode."""

    def __init__(self, base_url: str, api_key: str, fetch_json=None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.fetch_json = fetch_json or _default_fetch

    def _headers(self) -> dict[str, str]:
        return {"X-Emby-Token": self.api_key, "Accept": "application/json"}

    def discover_libraries(self) -> list[dict]:
        payload = self.fetch_json(f"{self.base_url}/Library/VirtualFolders", self._headers())
        rows = payload if isinstance(payload, list) else payload.get("Items", [])
        result: list[dict] = []
        for row in rows:
            name = str(row.get("Name") or "").strip()
            if not name or name.casefold() == "collections":
                continue
            library_id = row.get("ItemId") or row.get("Id")
            if not library_id:
                continue
            result.append({
                "id": str(library_id),
                "name": name,
                "collection_type": row.get("CollectionType"),
                "locations": [str(x) for x in (row.get("Locations") or [])],
            })
        return result

    def video_stream_url(
        self,
        item_id: str,
        media_source_id: str | None = None,
        audio_stream_index: int | None = None,
        start_time_ticks: int | None = None,
        compatible_live_tv: bool = False,
        force_transcode: bool = False,
        play_session_id: str | None = None,
    ) -> str:
        """Build a GET-only Jellyfin video URL.

        Full Library live-TV playback asks Jellyfin for an MPEG-TS stream that is
        H.264/AAC compatible. Jellyfin may stream-copy already-compatible tracks
        and transcodes formats such as AV1/HEVC/Opus when needed.
        """
        params: dict[str, str] = {}
        suffix = "stream"
        if compatible_live_tv:
            suffix = "stream.ts"
            params.update({
                "static": "false",
                "Container": "ts",
                "VideoCodec": "h264",
                "AudioCodec": "aac",
                "RequireAvc": "true",
                "EnableAutoStreamCopy": "false" if force_transcode else "true",
                "AllowVideoStreamCopy": "false" if force_transcode else "true",
                "AllowAudioStreamCopy": "false" if force_transcode else "true",
            })
        else:
            params["static"] = "true"
        if media_source_id:
            params["MediaSourceId"] = str(media_source_id)
        if audio_stream_index is not None:
            params["AudioStreamIndex"] = str(int(audio_stream_index))
        if start_time_ticks is not None and int(start_time_ticks) > 0:
            params["StartTimeTicks"] = str(int(start_time_ticks))
        if play_session_id:
            params["PlaySessionId"] = str(play_session_id)
        quoted_item = urllib.parse.quote(str(item_id), safe="")
        return f"{self.base_url}/Videos/{quoted_item}/{suffix}?{urllib.parse.urlencode(params)}"

    @staticmethod
    def _preferred_audio_stream_index(media_source: dict | None) -> int | None:
        streams = (media_source or {}).get("MediaStreams") or []
        audio = [row for row in streams if isinstance(row, dict) and str(row.get("Type") or "").casefold() == "audio" and row.get("Index") is not None]
        if not audio:
            return None

        def quality(row: dict) -> tuple[int, int, int]:
            try:
                channels = int(row.get("Channels") or 0)
            except (TypeError, ValueError):
                channels = 0
            try:
                bitrate = int(row.get("BitRate") or 0)
            except (TypeError, ValueError):
                bitrate = 0
            return channels, bitrate, -int(row.get("Index") or 0)

        english = []
        for row in audio:
            language = str(row.get("Language") or "").strip().casefold()
            if language in {"eng", "en", "english"} or language.startswith("en-"):
                english.append(row)
        if english:
            return int(max(english, key=quality)["Index"])
        default = next((row for row in audio if row.get("IsDefault")), None)
        if default is not None:
            return int(default["Index"])
        return int(audio[0]["Index"])

    def fetch_library_items(self, library_id: str) -> list[dict]:
        params = urllib.parse.urlencode({
            "ParentId": library_id,
            "Recursive": "true",
            "IncludeItemTypes": "Movie,Episode",
            "Fields": "Genres,Tags,Path,SeriesName,ParentIndexNumber,IndexNumber,ImageTags,MediaSources,MediaStreams",
            "EnableImages": "false",
            "EnableUserData": "false",
        })
        payload = self.fetch_json(f"{self.base_url}/Items?{params}", self._headers())
        result: list[dict] = []
        for row in payload.get("Items", []):
            item_id = row.get("Id")
            item_type = str(row.get("Type") or "")
            if not item_id or item_type not in {"Movie", "Episode"}:
                continue
            ticks = row.get("RunTimeTicks") or 0
            try:
                duration = max(0, int(round(float(ticks) / 10_000_000)))
            except (TypeError, ValueError):
                duration = 0
            image_tag = (row.get("ImageTags") or {}).get("Primary")
            media_sources = row.get("MediaSources") or []
            selected_source = next(
                (src for src in media_sources if isinstance(src, dict) and src.get("Id")),
                None,
            )
            media_source_id = str(selected_source.get("Id")) if selected_source else None
            stream_source = selected_source if selected_source and selected_source.get("MediaStreams") else {"MediaStreams": row.get("MediaStreams") or []}
            audio_stream_index = self._preferred_audio_stream_index(stream_source)
            warning = None
            if not item_id:
                warning = "Missing Jellyfin item ID"
            elif duration <= 0:
                warning = "Missing or zero runtime"
            result.append({
                "jellyfin_item_id": str(item_id),
                "jellyfin_media_source_id": media_source_id,
                **({"jellyfin_audio_stream_index": audio_stream_index} if audio_stream_index is not None else {}),
                "stream_warning": warning,
                "jellyfin_path": row.get("Path"),
                "kind": "movie" if item_type == "Movie" else "episode",
                "title": str(row.get("Name") or ""),
                "year": row.get("ProductionYear"),
                "duration_seconds": duration,
                "genres": [str(x) for x in (row.get("Genres") or [])],
                "tags": [str(x) for x in (row.get("Tags") or [])],
                "series_name": row.get("SeriesName"),
                "season_number": row.get("ParentIndexNumber"),
                "episode_number": row.get("IndexNumber"),
                "artwork_ref": f"{item_id}:{image_tag}" if image_tag else None,
            })
        return result
