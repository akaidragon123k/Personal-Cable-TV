from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo


def _zone(tz_name: str):
    try:
        return ZoneInfo(tz_name)
    except Exception:
        return timezone.utc


def is_channel_active(channel: dict, at: datetime | None = None, tz_name: str = "UTC") -> bool:
    """Return whether a channel should currently be exposed to Jellyfin.

    Normal channels are active whenever their enabled flag is on. Seasonal
    channels repeat every year using inclusive MM-DD boundaries. A start date
    later in the year than the end date represents a window crossing New Year.
    """
    if not bool(channel.get("enabled", 1)):
        return False
    if not bool(channel.get("seasonal_enabled", 0)):
        return True
    start = (channel.get("seasonal_start") or "").strip()
    end = (channel.get("seasonal_end") or "").strip()
    if not start or not end:
        return False
    at = at or datetime.now(timezone.utc)
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    mmdd = at.astimezone(_zone(tz_name)).strftime("%m-%d")
    if start <= end:
        return start <= mmdd <= end
    return mmdd >= start or mmdd <= end
