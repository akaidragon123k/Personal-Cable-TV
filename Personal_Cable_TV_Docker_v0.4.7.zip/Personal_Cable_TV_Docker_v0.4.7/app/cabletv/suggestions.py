from __future__ import annotations

import json
from collections import Counter

from .categories import automatic_channel_name


SEASONAL_TAGS = {
    "Christmas": {"aliases": {"christmas", "xmas"}, "start": "12-01", "end": "12-31"},
    "Halloween": {"aliases": {"halloween"}, "start": "10-01", "end": "10-31"},
    "Thanksgiving": {"aliases": {"thanksgiving"}, "start": "11-01", "end": "11-30"},
    "Valentine's": {"aliases": {"valentine", "valentine's day", "valentines"}, "start": "02-01", "end": "02-14"},
    "Easter / Spring": {"aliases": {"easter", "spring"}, "start": "03-01", "end": "04-30"},
}

REGULAR_TAGS = {"marvel": "Marvel", "dc": "DC"}


def _filter_key(filter_spec: dict) -> str:
    return json.dumps(filter_spec, sort_keys=True, separators=(",", ":"))


class SuggestionEngine:
    def __init__(self, db, minimum_items: int = 5):
        self.db = db
        self.minimum_items = max(1, int(minimum_items))

    def _existing(self) -> set[tuple[str, str]]:
        result: set[tuple[str, str]] = set()
        for channel in self.db.list_channels():
            if channel.get("source_mode") != "full" or not channel.get("source_library_id"):
                continue
            result.add((str(channel["source_library_id"]), _filter_key(channel.get("filter") or {})))
        return result

    def generate(self) -> list[dict]:
        existing = self._existing()
        suggestions: list[dict] = []
        for library in self.db.list_full_libraries(include_ignored=False):
            library_id = str(library["id"])
            library_name = str(library["name"])
            items = self.db.list_media(source_mode="full", library_id=library_id, playable_only=True)
            if not items:
                continue

            genre_counts: Counter[str] = Counter()
            genre_display: dict[str, str] = {}
            tag_counts: Counter[str] = Counter()
            tag_display: dict[str, str] = {}
            for item in items:
                for genre in item.get("genres") or []:
                    key = str(genre).strip().casefold()
                    if key:
                        genre_counts[key] += 1
                        genre_display.setdefault(key, str(genre).strip())
                for tag in item.get("tags") or []:
                    key = str(tag).strip().casefold()
                    if key:
                        tag_counts[key] += 1
                        tag_display.setdefault(key, str(tag).strip())

            # Seasonal suggestions first so Automatic Create Channels can reserve low numbers predictably.
            for label, config in SEASONAL_TAGS.items():
                aliases = config["aliases"]
                matching = sum(
                    1 for item in items
                    if any(str(tag).strip().casefold() in aliases for tag in (item.get("tags") or []))
                )
                if matching < self.minimum_items:
                    continue
                if label == "Christmas":
                    filter_spec = {"tag": "Christmas"}
                elif len(aliases) == 1:
                    filter_spec = {"tag": next(iter(aliases)).title()}
                else:
                    filter_spec = {"tags_any": sorted(tag.title() for tag in aliases)}
                if (library_id, _filter_key(filter_spec)) in existing:
                    continue
                suggestions.append({
                    "source_library_id": library_id,
                    "source_library_name": library_name,
                    "name": automatic_channel_name(library_name, label),
                    "filter": filter_spec,
                    "matching_count": matching,
                    "seasonal": True,
                    "seasonal_start": config["start"],
                    "seasonal_end": config["end"],
                })

            for key, count in sorted(genre_counts.items(), key=lambda kv: (kv[0])):
                if count < self.minimum_items:
                    continue
                display = genre_display[key]
                filter_spec = {"genre": display}
                if (library_id, _filter_key(filter_spec)) in existing:
                    continue
                suggestions.append({
                    "source_library_id": library_id,
                    "source_library_name": library_name,
                    "name": automatic_channel_name(library_name, display),
                    "filter": filter_spec,
                    "matching_count": count,
                    "seasonal": False,
                    "seasonal_start": None,
                    "seasonal_end": None,
                })

            for key, display in REGULAR_TAGS.items():
                count = tag_counts.get(key, 0)
                if count < self.minimum_items:
                    continue
                filter_spec = {"tag": display}
                if (library_id, _filter_key(filter_spec)) in existing:
                    continue
                suggestions.append({
                    "source_library_id": library_id,
                    "source_library_name": library_name,
                    "name": automatic_channel_name(library_name, display),
                    "filter": filter_spec,
                    "matching_count": count,
                    "seasonal": False,
                    "seasonal_start": None,
                    "seasonal_end": None,
                })

        suggestions.sort(key=lambda s: (not s["seasonal"], s["source_library_name"].casefold(), s["name"].casefold()))
        return suggestions

    def allocate_channel_number(self, seasonal: bool) -> int | None:
        occupied = {int(channel["number"]) for channel in self.db.list_channels()}
        if seasonal:
            for number in range(1, 21):
                if number not in occupied:
                    return number
            return None
        number = 100
        while number in occupied:
            number += 1
        return number

    def create_suggestion(self, source_library_id: str, filter_spec: dict) -> dict:
        wanted_library = str(source_library_id)
        wanted_key = _filter_key(filter_spec or {})
        suggestion = next((
            item for item in self.generate()
            if str(item.get("source_library_id")) == wanted_library
            and _filter_key(item.get("filter") or {}) == wanted_key
        ), None)
        if suggestion is None:
            raise ValueError("This channel suggestion is no longer eligible; run Sync Now and review suggestions again")
        seasonal = bool(suggestion.get("seasonal"))
        number = self.allocate_channel_number(seasonal=seasonal)
        if number is None:
            raise ValueError("No free seasonal slots remain in reserved channels 1-20")
        channel_id = self.db.create_full_channel(
            number=number,
            name=suggestion["name"],
            source_library_id=suggestion["source_library_id"],
            filter_spec=suggestion["filter"],
            seasonal_enabled=seasonal,
            seasonal_start=suggestion.get("seasonal_start"),
            seasonal_end=suggestion.get("seasonal_end"),
            auto_created=False,
        )
        return {
            "channel_id": channel_id,
            "number": number,
            "name": suggestion["name"],
            "source_library_id": suggestion["source_library_id"],
            "seasonal": seasonal,
        }

    def create_all_eligible(self) -> dict:
        created: list[dict] = []
        skipped: list[dict] = []
        for suggestion in self.generate():
            seasonal = bool(suggestion.get("seasonal"))
            number = self.allocate_channel_number(seasonal=seasonal)
            if number is None:
                skipped.append({
                    "suggestion": suggestion,
                    "reason": "No free seasonal slots remain in reserved channels 1-20",
                })
                continue
            channel_id = self.db.create_full_channel(
                number=number,
                name=suggestion["name"],
                source_library_id=suggestion["source_library_id"],
                filter_spec=suggestion["filter"],
                seasonal_enabled=seasonal,
                seasonal_start=suggestion.get("seasonal_start"),
                seasonal_end=suggestion.get("seasonal_end"),
                auto_created=True,
            )
            created.append({
                "channel_id": channel_id,
                "number": number,
                "name": suggestion["name"],
                "source_library_id": suggestion["source_library_id"],
                "seasonal": seasonal,
            })
        return {
            "created_count": len(created),
            "skipped_count": len(skipped),
            "created": created,
            "skipped": skipped,
        }
