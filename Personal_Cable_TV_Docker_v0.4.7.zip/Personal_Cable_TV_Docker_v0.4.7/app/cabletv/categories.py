from __future__ import annotations

GUIDE_CATEGORIES = (
    "Movies",
    "TV Shows",
    "Anime Movies",
    "Anime Shows",
    "Cartoons",
    "Cartoon Movies",
    "DC & Marvel",
    "Short Films",
    "Seasonal",
    "All Channels",
)

PERSISTED_SOURCE_CATEGORIES = GUIDE_CATEGORIES[:8]


def _movie_like(collection_type: str | None) -> bool:
    return str(collection_type or "").casefold() in {"movies", "movie", "boxsets"}


def _show_like(collection_type: str | None) -> bool:
    return str(collection_type or "").casefold() in {"tvshows", "shows", "show"}


def detect_guide_category(name: str, collection_type: str | None) -> str:
    key = str(name or "").casefold()
    movie_like = _movie_like(collection_type)
    show_like = _show_like(collection_type)
    if "anime" in key and movie_like:
        return "Anime Movies"
    if "anime" in key and show_like:
        return "Anime Shows"
    if "cartoon" in key and movie_like:
        return "Cartoon Movies"
    if "cartoon" in key and show_like:
        return "Cartoons"
    if "dc" in key or "marvel" in key:
        return "DC & Marvel"
    if "short" in key or "shot film" in key:
        return "Short Films"
    if movie_like:
        return "Movies"
    if show_like:
        return "TV Shows"
    return "TV Shows"


def normalize_guide_category(value: str) -> str:
    category = str(value or "").strip()
    if category not in PERSISTED_SOURCE_CATEGORIES:
        raise ValueError(f"Unknown guide category: {category}")
    return category


def automatic_channel_name(source_name: str, label: str) -> str:
    source = str(source_name or "").strip()
    suffix = str(label or "").strip()
    return f"{source} · {suffix}" if suffix else source
