from __future__ import annotations

import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator


class StreamSafetyError(RuntimeError):
    pass


def _allowed_roots(value: str | Path | Iterable[str | Path]) -> list[Path]:
    if isinstance(value, (str, Path)):
        values = [value]
    else:
        values = list(value)
    return [Path(root).resolve() for root in values]


def safe_media_path(path: str | Path, media_root: str | Path | Iterable[str | Path]) -> Path:
    roots = _allowed_roots(media_root)
    candidate = Path(path).resolve()
    inside = False
    for root in roots:
        try:
            candidate.relative_to(root)
            inside = True
            break
        except ValueError:
            continue
    if not inside:
        raise StreamSafetyError(f"Media path is outside the allowed media roots: {candidate}")
    if not candidate.is_file():
        raise StreamSafetyError(f"Media file does not exist: {candidate}")
    return candidate


def build_ffmpeg_command(
    path: str | Path,
    media_root: str | Path | Iterable[str | Path],
    offset_seconds: float,
    mode: str = "copy",
) -> list[str]:
    media = safe_media_path(path, media_root)
    offset = max(0.0, float(offset_seconds))
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error",
        "-ss", f"{offset:.3f}", "-re", "-i", str(media),
        "-map", "0:v:0?", "-map", "0:a:0?", "-sn", "-dn",
    ]
    if mode == "transcode":
        cmd += [
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "160k",
        ]
    else:
        cmd += ["-c:v", "copy", "-c:a", "copy"]
    cmd += ["-f", "mpegts", "pipe:1"]
    return cmd


def stream_channel_bytes(
    scheduler,
    channel_id: int,
    media_root: str | Path | Iterable[str | Path],
    mode: str = "copy",
    chunk_size: int = 64 * 1024,
) -> Iterator[bytes]:
    """Yield a continuous MPEG-TS channel, joining the current program in progress."""
    while True:
        now = datetime.now(timezone.utc)
        current = scheduler.current_program(channel_id, now)
        if not current:
            scheduler.ensure_all_channels(now, hours=96)
            current = scheduler.current_program(channel_id, now)
            if not current:
                return
        try:
            cmd = build_ffmpeg_command(
                current["path"], media_root, current.get("offset_seconds", 0.0), mode=mode
            )
        except StreamSafetyError:
            return
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=0,
        )
        try:
            assert process.stdout is not None
            while True:
                chunk = process.stdout.read(chunk_size)
                if not chunk:
                    break
                yield chunk
        except GeneratorExit:
            process.terminate()
            raise
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
            if process.stdout:
                process.stdout.close()
        # The scheduler is wall-clock based. Re-resolve after every item so
        # a new viewer never gets a restarted program and the stream advances.
        time.sleep(0.05)
