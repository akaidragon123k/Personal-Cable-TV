from __future__ import annotations

import subprocess
import urllib.parse
import uuid
from dataclasses import dataclass
from typing import Iterator

from .jellyfin import JellyfinClient


class JellyfinPlaybackError(RuntimeError):
    pass


@dataclass(frozen=True)
class JellyfinResolvedStream:
    url: str
    media_source_id: str | None
    offset_seconds: float


def build_jellyfin_ffmpeg_command(url: str, api_key: str, offset_seconds: float = 0.0) -> list[str]:
    # The live schedule offset is already encoded into Jellyfin's GET URL as
    # StartTimeTicks. Do not seek again here.
    return [
        "ffmpeg", "-hide_banner", "-loglevel", "warning",
        "-headers", f"X-Emby-Token: {api_key}\r\n",
        "-re", "-i", url,
        "-map", "0:v:0?", "-map", "0:a:0?", "-sn", "-dn",
        "-c:v", "copy", "-c:a", "copy",
        "-f", "mpegts", "pipe:1",
    ]



class JellyfinPlaybackAdapter:
    def __init__(self, client: JellyfinClient):
        self.client = client

    @staticmethod
    def _reject_recursive(url: str) -> None:
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.casefold()
        if "/livetv/" in path:
            raise JellyfinPlaybackError("Refusing recursive Jellyfin Live TV playback source")
        if "/iptv/channel/" in path:
            raise JellyfinPlaybackError("Refusing recursive Personal Cable TV channel source")

    def resolve(self, media: dict, offset_seconds: float) -> JellyfinResolvedStream:
        item_id = media.get("jellyfin_item_id")
        if not item_id:
            raise JellyfinPlaybackError("Missing Jellyfin item ID")
        offset = max(0.0, float(offset_seconds or 0.0))
        requested_source = media.get("jellyfin_media_source_id")
        try:
            start_ticks = int(round(offset * 10_000_000))
            play_session_id = uuid.uuid4().hex
            url = self.client.video_stream_url(
                str(item_id),
                media_source_id=requested_source,
                audio_stream_index=media.get("jellyfin_audio_stream_index"),
                start_time_ticks=start_ticks,
                compatible_live_tv=True,
                force_transcode=offset > 0.0,
                play_session_id=play_session_id,
            )
        except Exception as exc:
            raise JellyfinPlaybackError(f"Jellyfin stream URL failed: {exc}") from exc
        self._reject_recursive(url)
        if offset > 0.0:
            query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            if not query.get("StartTimeTicks"):
                raise JellyfinPlaybackError("Jellyfin live playback did not include the requested start position")
        return JellyfinResolvedStream(
            url=url,
            media_source_id=str(requested_source) if requested_source else None,
            offset_seconds=offset,
        )

    def iter_mpegts(self, media: dict, offset_seconds: float, chunk_size: int = 65536) -> Iterator[bytes]:
        resolved = self.resolve(media, offset_seconds)
        cmd = build_jellyfin_ffmpeg_command(resolved.url, self.client.api_key, resolved.offset_seconds)
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=None,
            bufsize=0,
        )
        try:
            assert process.stdout is not None
            while True:
                chunk = process.stdout.read(chunk_size)
                if not chunk:
                    break
                yield chunk
        except GeneratorExit:
            if process.poll() is None:
                process.terminate()
            raise
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
            if process.stdout:
                process.stdout.close()
