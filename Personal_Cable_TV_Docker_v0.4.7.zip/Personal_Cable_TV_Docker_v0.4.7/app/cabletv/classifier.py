from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path


def _norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


HORROR = (
    "friday the 13th", "nightmare on elm street", "freddy krueger", "halloween",
    "michael myers", "scream", "exorcist", "conjuring", "insidious", "saw",
    "texas chainsaw", "childs play", "chucky", "hellraiser", "evil dead",
    "paranormal activity", "the omen", "final destination",
)
CHRISTMAS = (
    "christmas", "xmas", "home alone", "the grinch", "grinch", "santa claus",
    "polar express", "elf", "miracle on 34th", "jingle all the way",
)
MARVEL = (
    "avengers", "iron man", "captain america", "thor", "guardians of the galaxy",
    "ant man", "black panther", "doctor strange", "spider man", "spiderman",
    "x men", "deadpool", "fantastic four", "captain marvel", "venom",
)
DC = (
    "batman", "dark knight", "superman", "wonder woman", "justice league",
    "aquaman", "the flash", "joker", "suicide squad", "shazam", "green lantern",
)
FAMILY = ("toy story", "lion king", "shrek", "finding nemo", "frozen", "moana", "inside out")


def classify_title(title: str) -> dict[str, list[str]]:
    normalized = _norm(title)
    genres: set[str] = set()
    tags: set[str] = set()
    if any(k in normalized for k in HORROR):
        genres.add("Horror")
    if any(k in normalized for k in CHRISTMAS):
        tags.add("Christmas")
    if any(k in normalized for k in MARVEL):
        tags.add("Marvel")
        genres.add("Action")
    if any(k in normalized for k in DC):
        tags.add("DC")
        genres.add("Action")
    if any(k in normalized for k in FAMILY):
        genres.add("Family")
    return {"genres": sorted(genres), "tags": sorted(tags)}


def read_nfo_metadata(path: Path) -> dict:
    result = {"title": None, "year": None, "genres": [], "tags": []}
    if not path.exists():
        return result
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return result
    title = root.findtext("title")
    year = root.findtext("year")
    result["title"] = title.strip() if title else None
    try:
        result["year"] = int(year) if year else None
    except ValueError:
        result["year"] = None
    result["genres"] = [e.text.strip() for e in root.findall("genre") if e.text and e.text.strip()]
    result["tags"] = [e.text.strip() for e in root.findall("tag") if e.text and e.text.strip()]
    return result


def title_and_year_from_filename(path: Path) -> tuple[str, int | None]:
    stem = path.stem.replace(".", " ").replace("_", " ")
    match = re.search(r"(?:\(|\[)?((?:19|20)\d{2})(?:\)|\])?", stem)
    year = int(match.group(1)) if match else None
    if match:
        stem = stem[: match.start()]
    stem = re.sub(r"\s+", " ", stem).strip(" -._")
    return stem or path.stem, year
