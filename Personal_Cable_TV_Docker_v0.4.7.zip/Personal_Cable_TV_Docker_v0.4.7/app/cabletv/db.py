from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    year INTEGER,
    duration_seconds INTEGER NOT NULL,
    genres TEXT NOT NULL DEFAULT '[]',
    tags TEXT NOT NULL DEFAULT '[]',
    series_name TEXT,
    season_number INTEGER,
    episode_number INTEGER,
    source_mode TEXT NOT NULL DEFAULT 'test',
    jellyfin_library_id TEXT,
    jellyfin_item_id TEXT,
    jellyfin_media_source_id TEXT,
    jellyfin_audio_stream_index INTEGER,
    jellyfin_path TEXT,
    playback_path TEXT,
    stream_warning TEXT,
    playable INTEGER NOT NULL DEFAULT 1,
    artwork_ref TEXT,
    last_synced_at TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS full_libraries (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    collection_type TEXT,
    locations TEXT NOT NULL DEFAULT '[]',
    last_synced_at TEXT,
    last_error TEXT,
    ignored INTEGER NOT NULL DEFAULT 0,
    guide_category TEXT
);
CREATE TABLE IF NOT EXISTS full_library_mappings (
    library_id TEXT PRIMARY KEY REFERENCES full_libraries(id) ON DELETE CASCADE,
    jellyfin_prefix TEXT NOT NULL,
    playback_prefix TEXT NOT NULL,
    verified_read_only INTEGER NOT NULL DEFAULT 0,
    verified_at TEXT
);
CREATE TABLE IF NOT EXISTS full_sync_state (
    id INTEGER PRIMARY KEY CHECK(id=1),
    last_success_at TEXT,
    next_sync_at TEXT,
    last_error TEXT
);
INSERT OR IGNORE INTO full_sync_state(id) VALUES(1);
CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number INTEGER NOT NULL UNIQUE,
    name TEXT NOT NULL,
    default_preset TEXT NOT NULL DEFAULT 'all_movies',
    commercials_enabled INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    seasonal_enabled INTEGER NOT NULL DEFAULT 0,
    seasonal_start TEXT,
    seasonal_end TEXT,
    source_mode TEXT NOT NULL DEFAULT 'test',
    source_library_id TEXT,
    filter_json TEXT,
    auto_created INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    preset TEXT NOT NULL,
    days TEXT NOT NULL DEFAULT '[]',
    start_time TEXT NOT NULL DEFAULT '00:00',
    end_time TEXT NOT NULL DEFAULT '23:59',
    date_start TEXT,
    date_end TEXT,
    priority INTEGER NOT NULL DEFAULT 10
);
CREATE TABLE IF NOT EXISTS schedule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    media_id INTEGER REFERENCES media(id) ON DELETE CASCADE,
    start_utc TEXT NOT NULL,
    end_utc TEXT NOT NULL,
    is_commercial INTEGER NOT NULL DEFAULT 0,
    row_type TEXT NOT NULL DEFAULT 'content',
    next_title TEXT
);
CREATE INDEX IF NOT EXISTS idx_schedule_channel_time
    ON schedule(channel_id, start_utc, end_utc);
CREATE INDEX IF NOT EXISTS idx_media_source_library
    ON media(source_mode, jellyfin_library_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_media_jellyfin_item
    ON media(jellyfin_library_id, jellyfin_item_id)
    WHERE source_mode='full' AND jellyfin_library_id IS NOT NULL AND jellyfin_item_id IS NOT NULL;
"""


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def initialize(self) -> None:
        with self.connect() as conn:
            # Existing installs need columns added before SCHEMA creates indexes that use them.
            existing_media = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='media'").fetchone()
            if existing_media:
                media_columns = {row[1] for row in conn.execute("PRAGMA table_info(media)").fetchall()}
                media_migrations = {
                    "source_mode": "ALTER TABLE media ADD COLUMN source_mode TEXT NOT NULL DEFAULT 'test'",
                    "jellyfin_library_id": "ALTER TABLE media ADD COLUMN jellyfin_library_id TEXT",
                    "jellyfin_item_id": "ALTER TABLE media ADD COLUMN jellyfin_item_id TEXT",
                    "jellyfin_media_source_id": "ALTER TABLE media ADD COLUMN jellyfin_media_source_id TEXT",
                    "jellyfin_audio_stream_index": "ALTER TABLE media ADD COLUMN jellyfin_audio_stream_index INTEGER",
                    "jellyfin_path": "ALTER TABLE media ADD COLUMN jellyfin_path TEXT",
                    "playback_path": "ALTER TABLE media ADD COLUMN playback_path TEXT",
                    "stream_warning": "ALTER TABLE media ADD COLUMN stream_warning TEXT",
                    "playable": "ALTER TABLE media ADD COLUMN playable INTEGER NOT NULL DEFAULT 1",
                    "artwork_ref": "ALTER TABLE media ADD COLUMN artwork_ref TEXT",
                    "last_synced_at": "ALTER TABLE media ADD COLUMN last_synced_at TEXT",
                }
                for name, sql in media_migrations.items():
                    if name not in media_columns:
                        conn.execute(sql)
            existing_channels = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='channels'").fetchone()
            if existing_channels:
                columns = {row[1] for row in conn.execute("PRAGMA table_info(channels)").fetchall()}
                migrations = {
                    "seasonal_enabled": "ALTER TABLE channels ADD COLUMN seasonal_enabled INTEGER NOT NULL DEFAULT 0",
                    "seasonal_start": "ALTER TABLE channels ADD COLUMN seasonal_start TEXT",
                    "seasonal_end": "ALTER TABLE channels ADD COLUMN seasonal_end TEXT",
                    "source_mode": "ALTER TABLE channels ADD COLUMN source_mode TEXT NOT NULL DEFAULT 'test'",
                    "source_library_id": "ALTER TABLE channels ADD COLUMN source_library_id TEXT",
                    "filter_json": "ALTER TABLE channels ADD COLUMN filter_json TEXT",
                    "auto_created": "ALTER TABLE channels ADD COLUMN auto_created INTEGER NOT NULL DEFAULT 0",
                }
                for name, sql in migrations.items():
                    if name not in columns:
                        conn.execute(sql)
            existing_full_libraries = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='full_libraries'").fetchone()
            if existing_full_libraries:
                library_columns = {row[1] for row in conn.execute("PRAGMA table_info(full_libraries)").fetchall()}
                if "ignored" not in library_columns:
                    conn.execute("ALTER TABLE full_libraries ADD COLUMN ignored INTEGER NOT NULL DEFAULT 0")
                if "guide_category" not in library_columns:
                    conn.execute("ALTER TABLE full_libraries ADD COLUMN guide_category TEXT")

            existing_schedule = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schedule'").fetchone()
            if existing_schedule:
                schedule_info = {row[1]: row for row in conn.execute("PRAGMA table_info(schedule)").fetchall()}
                media_id_not_null = bool(schedule_info.get("media_id") and schedule_info["media_id"][3])
                if media_id_not_null:
                    conn.executescript("""
                    CREATE TABLE schedule_v043 (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
                        media_id INTEGER REFERENCES media(id) ON DELETE CASCADE,
                        start_utc TEXT NOT NULL,
                        end_utc TEXT NOT NULL,
                        is_commercial INTEGER NOT NULL DEFAULT 0,
                        row_type TEXT NOT NULL DEFAULT 'content',
                        next_title TEXT
                    );
                    INSERT INTO schedule_v043(id,channel_id,media_id,start_utc,end_utc,is_commercial,row_type,next_title)
                    SELECT id,channel_id,media_id,start_utc,end_utc,is_commercial,
                           CASE WHEN is_commercial=1 THEN 'commercial' ELSE 'content' END, NULL
                    FROM schedule;
                    DROP TABLE schedule;
                    ALTER TABLE schedule_v043 RENAME TO schedule;
                    CREATE INDEX IF NOT EXISTS idx_schedule_channel_time
                        ON schedule(channel_id, start_utc, end_utc);
                    """)
                else:
                    if "row_type" not in schedule_info:
                        conn.execute("ALTER TABLE schedule ADD COLUMN row_type TEXT NOT NULL DEFAULT 'content'")
                        conn.execute("UPDATE schedule SET row_type=CASE WHEN is_commercial=1 THEN 'commercial' ELSE 'content' END")
                    if "next_title" not in schedule_info:
                        conn.execute("ALTER TABLE schedule ADD COLUMN next_title TEXT")
            conn.executescript(SCHEMA)

            from .categories import detect_guide_category
            libraries = conn.execute(
                "SELECT id,name,collection_type,guide_category FROM full_libraries"
            ).fetchall()
            for library in libraries:
                if not library["guide_category"]:
                    conn.execute(
                        "UPDATE full_libraries SET guide_category=? WHERE id=?",
                        (detect_guide_category(library["name"], library["collection_type"]), library["id"]),
                    )

        self.migrate_auto_channel_names_v043()

    def migrate_auto_channel_names_v043(self) -> None:
        from .categories import automatic_channel_name

        if self.get_setting("migration_v043_auto_names") == "1":
            return
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT c.id,c.filter_json,l.name AS library_name
                   FROM channels c
                   JOIN full_libraries l ON l.id=c.source_library_id
                   WHERE c.source_mode='full' AND c.auto_created=1"""
            ).fetchall()
            for row in rows:
                try:
                    spec = json.loads(row["filter_json"] or "{}")
                except json.JSONDecodeError:
                    continue
                label = None
                if spec.get("genre"):
                    label = str(spec["genre"])
                elif spec.get("tag"):
                    label = str(spec["tag"])
                elif spec.get("tags_any"):
                    values = [str(value) for value in spec.get("tags_any") or [] if str(value).strip()]
                    label = values[0] if values else None
                if label:
                    conn.execute(
                        "UPDATE channels SET name=? WHERE id=?",
                        (automatic_channel_name(row["library_name"], label), int(row["id"])),
                    )
        self.set_setting("migration_v043_auto_names", "1")

    def table_names(self) -> list[str]:
        with self.connect() as conn:
            rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        return [row[0] for row in rows]

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )

    def get_setting(self, key: str, default: str | None = None) -> str | None:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    def replace_media(self, items: Iterable[dict[str, Any]]) -> int:
        """Replace Test Mode scan rows without touching Full Library media."""
        rows = list(items)
        with self.connect() as conn:
            seen = []
            for item in rows:
                seen.append(item["path"])
                conn.execute(
                    """INSERT INTO media(path,kind,title,year,duration_seconds,genres,tags,series_name,season_number,episode_number,source_mode,playable)
                       VALUES(?,?,?,?,?,?,?,?,?,?,'test',1)
                       ON CONFLICT(path) DO UPDATE SET
                         kind=excluded.kind,title=excluded.title,year=excluded.year,
                         duration_seconds=excluded.duration_seconds,genres=excluded.genres,
                         tags=excluded.tags,series_name=excluded.series_name,
                         season_number=excluded.season_number,episode_number=excluded.episode_number,
                         source_mode='test',playable=1,updated_at=CURRENT_TIMESTAMP""",
                    (
                        item["path"], item["kind"], item["title"], item.get("year"),
                        int(item["duration_seconds"]), json.dumps(item.get("genres", [])),
                        json.dumps(item.get("tags", [])), item.get("series_name"),
                        item.get("season_number"), item.get("episode_number"),
                    ),
                )
            if seen:
                placeholders = ",".join("?" for _ in seen)
                conn.execute(
                    f"DELETE FROM media WHERE source_mode='test' AND path NOT IN ({placeholders})", seen
                )
            else:
                conn.execute("DELETE FROM media WHERE source_mode='test'")
        return len(rows)

    def upsert_full_library(self, library: dict[str, Any]) -> None:
        from .categories import detect_guide_category

        guide_category = library.get("guide_category") or detect_guide_category(
            str(library["name"]), library.get("collection_type")
        )
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO full_libraries(id,name,collection_type,locations,last_synced_at,last_error,guide_category)
                   VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET
                     name=excluded.name,collection_type=excluded.collection_type,locations=excluded.locations,
                     last_synced_at=COALESCE(excluded.last_synced_at,full_libraries.last_synced_at),
                     last_error=excluded.last_error,
                     guide_category=COALESCE(NULLIF(full_libraries.guide_category,''),excluded.guide_category)""",
                (
                    str(library["id"]), str(library["name"]), library.get("collection_type"),
                    json.dumps(library.get("locations") or []), library.get("last_synced_at"),
                    library.get("last_error"), guide_category,
                ),
            )

    def list_full_libraries(self, include_ignored: bool | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM full_libraries"
        params: list[Any] = []
        if include_ignored is False:
            sql += " WHERE ignored=0"
        elif include_ignored is True:
            sql += " WHERE ignored=1"
        sql += " ORDER BY name COLLATE NOCASE,id"
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["locations"] = json.loads(item.get("locations") or "[]")
            result.append(item)
        return result


    def get_full_library(self, library_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM full_libraries WHERE id=?", (str(library_id),)).fetchone()
        if not row:
            return None
        item = dict(row)
        item["locations"] = json.loads(item.get("locations") or "[]")
        return item

    def set_full_library_error(self, library_id: str, error: str | None) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE full_libraries SET last_error=? WHERE id=?", (error, str(library_id)))

    def set_full_library_ignored(self, library_id: str, ignored: bool) -> None:
        with self.connect() as conn:
            cur = conn.execute(
                "UPDATE full_libraries SET ignored=? WHERE id=?",
                (1 if ignored else 0, str(library_id)),
            )
            if cur.rowcount == 0:
                raise ValueError("Unknown source library")

    def set_full_library_guide_category(self, library_id: str, category: str) -> None:
        from .categories import normalize_guide_category

        category = normalize_guide_category(category)
        with self.connect() as conn:
            cur = conn.execute(
                "UPDATE full_libraries SET guide_category=? WHERE id=?",
                (category, str(library_id)),
            )
            if cur.rowcount != 1:
                raise ValueError(f"Unknown source library: {library_id}")

    def get_channel_guide_category(self, channel: dict[str, Any] | int) -> str | None:
        row = self.get_channel(int(channel)) if isinstance(channel, int) else channel
        if not row or row.get("source_mode") != "full" or not row.get("source_library_id"):
            return None
        library = self.get_full_library(str(row["source_library_id"]))
        return str(library.get("guide_category")) if library and library.get("guide_category") else None

    def set_library_mapping(
        self, library_id: str, jellyfin_prefix: str, playback_prefix: str,
        verified_read_only: bool, verified_at: str | None = None,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO full_library_mappings(
                     library_id,jellyfin_prefix,playback_prefix,verified_read_only,verified_at
                   ) VALUES(?,?,?,?,?)
                   ON CONFLICT(library_id) DO UPDATE SET
                     jellyfin_prefix=excluded.jellyfin_prefix,
                     playback_prefix=excluded.playback_prefix,
                     verified_read_only=excluded.verified_read_only,
                     verified_at=excluded.verified_at""",
                (str(library_id), jellyfin_prefix, playback_prefix, 1 if verified_read_only else 0, verified_at),
            )

    def get_library_mapping(self, library_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT * FROM full_library_mappings WHERE library_id=?", (str(library_id),)
            ).fetchone()
        return dict(row) if row else None

    def list_library_mappings(self) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM full_library_mappings ORDER BY library_id"
            ).fetchall()
        return [dict(row) for row in rows]

    def set_full_sync_state(
        self, last_success_at: str | None, next_sync_at: str | None, last_error: str | None
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO full_sync_state(id,last_success_at,next_sync_at,last_error) VALUES(1,?,?,?)
                   ON CONFLICT(id) DO UPDATE SET
                     last_success_at=excluded.last_success_at,
                     next_sync_at=excluded.next_sync_at,
                     last_error=excluded.last_error""",
                (last_success_at, next_sync_at, last_error),
            )

    def get_full_sync_state(self) -> dict[str, Any]:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT last_success_at,next_sync_at,last_error FROM full_sync_state WHERE id=1"
            ).fetchone()
        return dict(row) if row else {"last_success_at": None, "next_sync_at": None, "last_error": None}
    def replace_full_library_media(self, library_id: str, items: Iterable[dict[str, Any]]) -> int:
        rows = list(items)
        with self.connect() as conn:
            seen: list[str] = []
            for item in rows:
                item_id = str(item["jellyfin_item_id"])
                seen.append(item_id)
                synthetic_path = f"jellyfin://{library_id}/{item_id}"
                conn.execute(
                    """INSERT INTO media(
                         path,kind,title,year,duration_seconds,genres,tags,series_name,season_number,episode_number,
                         source_mode,jellyfin_library_id,jellyfin_item_id,jellyfin_media_source_id,jellyfin_audio_stream_index,jellyfin_path,playback_path,stream_warning,playable,artwork_ref,last_synced_at
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,'full',?,?,?,?,?,NULL,?,0,?,COALESCE(?,CURRENT_TIMESTAMP))
                       ON CONFLICT(path) DO UPDATE SET
                         kind=excluded.kind,title=excluded.title,year=excluded.year,duration_seconds=excluded.duration_seconds,
                         genres=excluded.genres,tags=excluded.tags,series_name=excluded.series_name,
                         season_number=excluded.season_number,episode_number=excluded.episode_number,
                         jellyfin_library_id=excluded.jellyfin_library_id,jellyfin_item_id=excluded.jellyfin_item_id,
                         jellyfin_media_source_id=excluded.jellyfin_media_source_id,jellyfin_audio_stream_index=excluded.jellyfin_audio_stream_index,jellyfin_path=excluded.jellyfin_path,
                         playback_path=NULL,stream_warning=excluded.stream_warning,playable=0,
                         artwork_ref=excluded.artwork_ref,last_synced_at=excluded.last_synced_at,updated_at=CURRENT_TIMESTAMP""",
                    (
                        synthetic_path, item["kind"], item["title"], item.get("year"), int(item["duration_seconds"]),
                        json.dumps(item.get("genres", [])), json.dumps(item.get("tags", [])), item.get("series_name"),
                        item.get("season_number"), item.get("episode_number"), str(library_id), item_id,
                        item.get("jellyfin_media_source_id"), item.get("jellyfin_audio_stream_index"), item.get("jellyfin_path"), item.get("stream_warning"),
                        item.get("artwork_ref"), item.get("last_synced_at"),
                    ),
                )
            if seen:
                placeholders = ",".join("?" for _ in seen)
                conn.execute(
                    f"DELETE FROM media WHERE source_mode='full' AND jellyfin_library_id=? "
                    f"AND jellyfin_item_id NOT IN ({placeholders})",
                    [str(library_id), *seen],
                )
            else:
                conn.execute(
                    "DELETE FROM media WHERE source_mode='full' AND jellyfin_library_id=?", (str(library_id),)
                )
        return len(rows)


    def set_full_media_stream_state(
        self, media_id: int, media_source_id: str | None, ready: bool, warning: str | None
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE media SET jellyfin_media_source_id=?, playable=?, stream_warning=?, playback_path=NULL, updated_at=CURRENT_TIMESTAMP "
                "WHERE id=? AND source_mode='full'",
                (media_source_id, 1 if ready else 0, warning or None, int(media_id)),
            )

    def list_media(
        self,
        source_mode: str | None = None,
        library_id: str | None = None,
        playable_only: bool = False,
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if source_mode is not None:
            clauses.append("source_mode=?")
            params.append(source_mode)
        if library_id is not None:
            clauses.append("jellyfin_library_id=?")
            params.append(library_id)
        if playable_only:
            clauses.append("playable=1")
        sql = "SELECT * FROM media"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY title COLLATE NOCASE"
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [self._decode_media(dict(r)) for r in rows]

    def set_media_resolution(self, media_id: int, playback_path: str | None, playable: bool) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE media SET playback_path=?, playable=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (playback_path, 1 if playable else 0, int(media_id)),
            )

    def get_media(self, media_id: int) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM media WHERE id=?", (media_id,)).fetchone()
        return self._decode_media(dict(row)) if row else None

    def update_media_metadata(self, media_id: int, genres: list[str], tags: list[str], year: int | None = None) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE media SET genres=?, tags=?, year=COALESCE(?,year), updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (json.dumps(genres), json.dumps(tags), year, media_id),
            )

    @staticmethod
    def _decode_media(row: dict[str, Any]) -> dict[str, Any]:
        row["genres"] = json.loads(row.get("genres") or "[]")
        row["tags"] = json.loads(row.get("tags") or "[]")
        return row

    @staticmethod
    def _decode_channel(row: dict[str, Any]) -> dict[str, Any]:
        raw = row.get("filter_json")
        row["filter"] = json.loads(raw) if raw else None
        return row

    def create_channel(self, number: int, name: str, default_preset: str, commercials_enabled: bool) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO channels(number,name,default_preset,commercials_enabled) VALUES(?,?,?,?)",
                (int(number), name.strip(), default_preset, 1 if commercials_enabled else 0),
            )
            return int(cur.lastrowid)

    def create_full_channel(
        self,
        number: int,
        name: str,
        source_library_id: str,
        filter_spec: dict[str, Any],
        commercials_enabled: bool = False,
        seasonal_enabled: bool = False,
        seasonal_start: str | None = None,
        seasonal_end: str | None = None,
        auto_created: bool = False,
    ) -> int:
        source_library = self.get_full_library(source_library_id)
        if not source_library:
            raise ValueError(f"Unknown source library: {source_library_id}")
        if source_library.get("ignored"):
            raise ValueError("Source library is ignored; restore it before creating channels")
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT INTO channels(
                     number,name,default_preset,commercials_enabled,enabled,seasonal_enabled,seasonal_start,seasonal_end,
                     source_mode,source_library_id,filter_json,auto_created
                   ) VALUES(?,?,'all',?,1,?,?,?,?,?,?,?)""",
                (
                    int(number), name.strip(), 1 if commercials_enabled else 0,
                    1 if seasonal_enabled else 0, seasonal_start or None, seasonal_end or None,
                    "full", str(source_library_id), json.dumps(filter_spec, sort_keys=True),
                    1 if auto_created else 0,
                ),
            )
            return int(cur.lastrowid)

    def update_channel(
        self,
        channel_id: int,
        number: int,
        name: str,
        default_preset: str,
        commercials_enabled: bool,
        seasonal_enabled: bool = False,
        seasonal_start: str | None = None,
        seasonal_end: str | None = None,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """UPDATE channels
                   SET number=?, name=?, default_preset=?, commercials_enabled=?,
                       seasonal_enabled=?, seasonal_start=?, seasonal_end=?
                   WHERE id=?""",
                (
                    int(number), name.strip(), default_preset, 1 if commercials_enabled else 0,
                    1 if seasonal_enabled else 0, seasonal_start or None, seasonal_end or None, int(channel_id),
                ),
            )

    def list_channels(self, enabled_only: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT * FROM channels"
        params: tuple[Any, ...] = ()
        if enabled_only:
            sql += " WHERE enabled=1"
        sql += " ORDER BY number"
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [self._decode_channel(dict(r)) for r in rows]

    def get_channel(self, channel_id: int) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM channels WHERE id=?", (channel_id,)).fetchone()
        return self._decode_channel(dict(row)) if row else None

    def delete_channel(self, channel_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM channels WHERE id=?", (channel_id,))

    def add_rule(
        self,
        channel_id: int,
        label: str,
        preset: str,
        days: list[int],
        start_time: str,
        end_time: str,
        date_start: str | None,
        date_end: str | None,
        priority: int = 10,
    ) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT INTO rules(channel_id,label,preset,days,start_time,end_time,date_start,date_end,priority)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (channel_id, label.strip(), preset, json.dumps(days), start_time, end_time,
                 date_start or None, date_end or None, int(priority)),
            )
            return int(cur.lastrowid)

    def list_rules(self, channel_id: int) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM rules WHERE channel_id=? ORDER BY priority DESC,id ASC", (channel_id,)
            ).fetchall()
        result = []
        for row in rows:
            d = dict(row)
            d["days"] = json.loads(d["days"] or "[]")
            result.append(d)
        return result

    def delete_rule(self, rule_id: int) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM rules WHERE id=?", (rule_id,))

    def clear_schedule(self, channel_id: int, start_utc: str | None = None, end_utc: str | None = None) -> None:
        with self.connect() as conn:
            if start_utc is None or end_utc is None:
                conn.execute("DELETE FROM schedule WHERE channel_id=?", (channel_id,))
            else:
                conn.execute(
                    "DELETE FROM schedule WHERE channel_id=? AND start_utc < ? AND end_utc > ?",
                    (channel_id, end_utc, start_utc),
                )

    def add_schedule_row(self, channel_id: int, media_id: int, start_utc: str, end_utc: str, is_commercial: bool) -> int:
        row_type = "commercial" if is_commercial else "content"
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT INTO schedule(channel_id,media_id,start_utc,end_utc,is_commercial,row_type,next_title)
                   VALUES(?,?,?,?,?,?,NULL)""",
                (channel_id, media_id, start_utc, end_utc, 1 if is_commercial else 0, row_type),
            )
            return int(cur.lastrowid)

    def add_filler_schedule_row(
        self, channel_id: int, start_utc: str, end_utc: str, next_title: str | None = None
    ) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT INTO schedule(channel_id,media_id,start_utc,end_utc,is_commercial,row_type,next_title)
                   VALUES(?,NULL,?,?,0,'filler',?)""",
                (int(channel_id), str(start_utc), str(end_utc), next_title),
            )
            return int(cur.lastrowid)

    def replace_schedule_rows(self, channel_id: int, rows: Iterable[dict[str, Any]]) -> int:
        prepared = []
        for row in rows:
            row_type = str(row.get("row_type") or "content")
            if row_type not in {"content", "commercial", "filler"}:
                raise ValueError(f"Unknown schedule row type: {row_type}")
            media_id = row.get("media_id")
            prepared.append((
                int(channel_id),
                int(media_id) if media_id is not None else None,
                str(row["start_utc"]),
                str(row["end_utc"]),
                1 if row_type == "commercial" else 0,
                row_type,
                row.get("next_title"),
            ))
        with self.connect() as conn:
            conn.execute("DELETE FROM schedule WHERE channel_id=?", (int(channel_id),))
            if prepared:
                conn.executemany(
                    """INSERT INTO schedule(
                         channel_id,media_id,start_utc,end_utc,is_commercial,row_type,next_title
                       ) VALUES(?,?,?,?,?,?,?)""",
                    prepared,
                )
        return len(prepared)

    def schedule_max_end_utc(self) -> str | None:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT MAX(s.end_utc)
                   FROM schedule s
                   JOIN channels c ON c.id=s.channel_id
                   WHERE c.enabled=1"""
            ).fetchone()
        return str(row[0]) if row and row[0] else None

    @staticmethod
    def _decode_schedule_row(row: dict[str, Any]) -> dict[str, Any]:
        row["genres"] = json.loads(row.get("genres") or "[]")
        row["tags"] = json.loads(row.get("tags") or "[]")
        if row.get("row_type") == "filler":
            row["title"] = f"Up Next: {row['next_title']}" if row.get("next_title") else "Up Next"
            row["kind"] = "filler"
            row["source_mode"] = "filler"
        return row

    def list_schedule(self, channel_id: int, start, end) -> list[dict[str, Any]]:
        start_iso = start.isoformat() if hasattr(start, "isoformat") else str(start)
        end_iso = end.isoformat() if hasattr(end, "isoformat") else str(end)
        with self.connect() as conn:
            rows = conn.execute(
                """SELECT s.*,COALESCE(m.playback_path,m.path) AS path,m.kind,m.title,m.year,m.duration_seconds,m.genres,m.tags,
                          m.series_name,m.season_number,m.episode_number,m.source_mode,m.jellyfin_library_id,m.jellyfin_item_id,m.playable
                   FROM schedule s LEFT JOIN media m ON m.id=s.media_id
                   WHERE s.channel_id=? AND s.start_utc < ? AND s.end_utc > ?
                   ORDER BY s.start_utc""",
                (channel_id, end_iso, start_iso),
            ).fetchall()
        return [self._decode_schedule_row(dict(r)) for r in rows]

    def schedule_at(self, channel_id: int, at_utc: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT s.*,COALESCE(m.playback_path,m.path) AS path,m.kind,m.title,m.year,m.duration_seconds,m.genres,m.tags,
                          m.series_name,m.season_number,m.episode_number,m.source_mode,m.jellyfin_library_id,m.jellyfin_item_id,m.playable
                   FROM schedule s LEFT JOIN media m ON m.id=s.media_id
                   WHERE s.channel_id=? AND s.start_utc <= ? AND s.end_utc > ?
                   ORDER BY s.start_utc DESC LIMIT 1""",
                (channel_id, at_utc, at_utc),
            ).fetchone()
        return self._decode_schedule_row(dict(row)) if row else None
