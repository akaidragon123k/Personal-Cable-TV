from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .jellyfin import JellyfinClient


class FullLibrarySyncService:
    """Synchronize Jellyfin libraries without destroying the last good snapshot."""

    def __init__(self, db, client_factory=None):
        self.db = db
        self.client_factory = client_factory or (lambda base_url, api_key: JellyfinClient(base_url, api_key))

    @staticmethod
    def _utc(value: datetime | None) -> datetime:
        value = value or datetime.now(timezone.utc)
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    def next_sync_at(self) -> datetime | None:
        value = self.db.get_full_sync_state().get("next_sync_at")
        return datetime.fromisoformat(value) if value else None

    def is_due(self, now: datetime | None = None) -> bool:
        now = self._utc(now)
        next_at = self.next_sync_at()
        if next_at is None:
            return True
        if next_at.tzinfo is None:
            next_at = next_at.replace(tzinfo=timezone.utc)
        return now >= next_at.astimezone(timezone.utc)

    def sync(self, base_url: str, api_key: str, now: datetime | None = None) -> dict:
        now = self._utc(now)
        state = self.db.get_full_sync_state()
        previous_success = state.get("last_success_at")
        next_at = now + timedelta(days=7)
        client = self.client_factory(base_url, api_key)

        try:
            libraries = client.discover_libraries()
        except Exception as exc:
            message = str(exc)
            self.db.set_full_sync_state(previous_success, next_at.isoformat(), message)
            return {
                "status": "error",
                "libraries_ok": 0,
                "libraries_failed": 0,
                "items": 0,
                "error": message,
            }

        ok = 0
        failed = 0
        item_count = 0
        stream_ready_count = 0
        stream_warning_count = 0
        errors: list[str] = []
        for library in libraries:
            library_id = str(library["id"])
            # Update discovery metadata but preserve prior successful sync timestamp until item refresh succeeds.
            existing = self.db.get_full_library(library_id) or {}
            discovered = dict(library)
            discovered["last_synced_at"] = existing.get("last_synced_at")
            discovered["last_error"] = None
            discovered["guide_category"] = existing.get("guide_category")
            self.db.upsert_full_library(discovered)
            # Ignored libraries remain known so they can be restored later, but
            # are not refreshed or used for new channel suggestions. Cached
            # media is intentionally preserved for rollback/existing channels.
            if existing.get("ignored"):
                continue
            try:
                items = client.fetch_library_items(library_id)
                stamped = []
                for item in items:
                    row = dict(item)
                    row["last_synced_at"] = now.isoformat()
                    stamped.append(row)
                self.db.replace_full_library_media(library_id, stamped)
                synced_rows = self.db.list_media(source_mode="full", library_id=library_id)
                for row in synced_rows:
                    ready = bool(row.get("jellyfin_item_id")) and int(row.get("duration_seconds") or 0) > 0
                    warning = None if ready else (row.get("stream_warning") or "Jellyfin playback metadata incomplete")
                    self.db.set_full_media_stream_state(
                        row["id"], row.get("jellyfin_media_source_id"), ready, warning
                    )
                    if ready:
                        stream_ready_count += 1
                    else:
                        stream_warning_count += 1
                refreshed = dict(library)
                refreshed["last_synced_at"] = now.isoformat()
                refreshed["last_error"] = None
                refreshed["guide_category"] = existing.get("guide_category")
                self.db.upsert_full_library(refreshed)
                ok += 1
                item_count += len(stamped)
            except Exception as exc:
                message = str(exc)
                self.db.set_full_library_error(library_id, message)
                failed += 1
                errors.append(f"{library.get('name') or library_id}: {message}")

        if failed == 0:
            self.db.set_full_sync_state(now.isoformat(), next_at.isoformat(), None)
            status = "ok"
        else:
            self.db.set_full_sync_state(previous_success, next_at.isoformat(), "; ".join(errors))
            status = "partial"
        return {
            "status": status,
            "libraries_ok": ok,
            "libraries_failed": failed,
            "items": item_count,
            "stream_ready_count": stream_ready_count,
            "stream_warning_count": stream_warning_count,
            "error": "; ".join(errors) if errors else None,
        }
