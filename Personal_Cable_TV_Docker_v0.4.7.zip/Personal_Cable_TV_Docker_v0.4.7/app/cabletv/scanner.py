from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from .classifier import classify_title, read_nfo_metadata, title_and_year_from_filename


VIDEO_EXTENSIONS = {".mkv", ".mp4", ".m4v", ".avi", ".mov", ".ts", ".mpeg", ".mpg", ".webm"}
KIND_DIRS = {
    "movies": "movie",
    "tv": "episode",
    "cartoons": "cartoon",
    "anime": "anime",
    "commercials": "commercial",
}


class MediaSafetyError(RuntimeError):
    pass


def _mount_read_only(path: Path) -> bool:
    """Return True when Linux mountinfo says the path is on an ro mount."""
    try:
        target = path.resolve()
        best_len = -1
        best_opts: set[str] | None = None
        with open("/proc/self/mountinfo", "r", encoding="utf-8") as fh:
            for line in fh:
                parts = line.rstrip("\n").split(" ")
                if "-" not in parts or len(parts) < 7:
                    continue
                mount_point = Path(parts[4].replace("\\040", " "))
                try:
                    target.relative_to(mount_point)
                except ValueError:
                    continue
                if len(str(mount_point)) > best_len:
                    best_len = len(str(mount_point))
                    best_opts = set(parts[5].split(","))
        return bool(best_opts and "ro" in best_opts and "rw" not in best_opts)
    except OSError:
        return False


# Public alias for Full Library mount verification.
mount_is_read_only = _mount_read_only

class MediaScanner:
    def __init__(self, media_root: str | Path, allow_writable_media: bool = False):
        self.media_root = Path(media_root)
        self.allow_writable_media = allow_writable_media

    def assert_media_is_read_only(self) -> None:
        if self.allow_writable_media:
            return
        if not self.media_root.exists():
            raise MediaSafetyError(f"Media root does not exist: {self.media_root}")
        if not _mount_read_only(self.media_root):
            raise MediaSafetyError(
                f"Media root {self.media_root} is writable or is not proven read-only. "
                "For safety the scan is blocked. Mount media with read_only: true."
            )

    def probe_duration(self, path: Path) -> int:
        cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "json", str(path),
        ]
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, timeout=20, check=True)
            duration = float(json.loads(cp.stdout)["format"]["duration"])
            return max(1, int(round(duration)))
        except (subprocess.SubprocessError, OSError, ValueError, KeyError, json.JSONDecodeError):
            return 0

    def scan(self) -> list[dict]:
        self.assert_media_is_read_only()
        results: list[dict] = []
        root = self.media_root.resolve()
        for directory, kind in KIND_DIRS.items():
            base = root / directory
            if not base.exists():
                continue
            for path in sorted(base.rglob("*")):
                if not path.is_file() or path.suffix.lower() not in VIDEO_EXTENSIONS:
                    continue
                duration = self.probe_duration(path)
                if duration <= 0:
                    continue
                file_title, file_year = title_and_year_from_filename(path)
                nfo = read_nfo_metadata(path.with_suffix(".nfo"))
                title = nfo["title"] or file_title
                year = nfo["year"] or file_year
                fallback = classify_title(title)
                genres = sorted(set(nfo["genres"] + fallback["genres"]))
                tags = sorted(set(nfo["tags"] + fallback["tags"]))
                season_number = episode_number = None
                series_name = None
                if kind in {"episode", "cartoon", "anime"}:
                    import re
                    m = re.search(r"[Ss](\d{1,2})[Ee](\d{1,3})", path.stem)
                    if m:
                        season_number, episode_number = int(m.group(1)), int(m.group(2))
                    if path.parent != base:
                        series_name = path.parent.name
                results.append({
                    "path": str(path.resolve()),
                    "kind": kind,
                    "title": title,
                    "year": year,
                    "duration_seconds": duration,
                    "genres": genres,
                    "tags": tags,
                    "series_name": series_name,
                    "season_number": season_number,
                    "episode_number": episode_number,
                })
        return results
