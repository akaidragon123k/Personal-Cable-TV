from __future__ import annotations

import subprocess
from typing import Iterator


def build_filler_ffmpeg_command(
    channel_name: str,
    next_title: str | None,
    remaining_seconds: float,
) -> list[str]:
    del channel_name, next_title
    duration = max(1, int(remaining_seconds))
    return [
        "ffmpeg", "-hide_banner", "-loglevel", "warning",
        "-re", "-f", "lavfi", "-i", "color=c=black:s=1280x720:r=30",
        "-re", "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
        "-t", str(duration),
        "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
        "-f", "mpegts", "pipe:1",
    ]


def iter_filler_mpegts(
    channel_name: str,
    next_title: str | None,
    remaining_seconds: float,
    chunk_size: int = 65536,
) -> Iterator[bytes]:
    cmd = build_filler_ffmpeg_command(channel_name, next_title, remaining_seconds)
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=None, bufsize=0)
    try:
        assert process.stdout is not None
        while True:
            chunk = process.stdout.read(chunk_size)
            if not chunk:
                break
            yield chunk
    except GeneratorExit:
        if process.poll() is None:
            process.terminate()
        raise
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
        if process.stdout:
            process.stdout.close()
