from __future__ import annotations

from datetime import datetime, timezone
import xml.etree.ElementTree as ET

from .availability import is_channel_active


def _visible_channels(db, at: datetime | None, tz_name: str) -> list[dict]:
    at = at or datetime.now(timezone.utc)
    channels = [ch for ch in db.list_channels(enabled_only=True) if is_channel_active(ch, at, tz_name)]
    return sorted(channels, key=lambda ch: int(ch["number"]))


def _channel_group(db, channel: dict) -> str:
    return db.get_channel_guide_category(channel) or "Personal Cable TV"


def build_m3u(db, base_url: str, at: datetime | None = None, tz_name: str = "UTC") -> str:
    base_url = base_url.rstrip("/")
    lines = ["#EXTM3U"]
    for ch in _visible_channels(db, at, tz_name):
        tvg_id = f"pctv-{ch['number']}"
        name = ch["name"].replace("\n", " ").strip()
        lines.append(
            f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-chno="{ch["number"]}" group-title="{_channel_group(db, ch)}",{name}'
        )
        lines.append(f"{base_url}/iptv/channel/{ch['id']}.ts")
    return "\n".join(lines) + "\n"


def _xmltv_time(value: str | datetime) -> str:
    if isinstance(value, str):
        dt = datetime.fromisoformat(value)
    else:
        dt = value
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y%m%d%H%M%S +0000")


def build_xmltv(
    db,
    start: datetime,
    end: datetime,
    tz_name: str = "UTC",
    at: datetime | None = None,
) -> str:
    tv = ET.Element("tv", {"generator-info-name": "Personal Cable TV"})
    channels = _visible_channels(db, at, tz_name)
    for ch in channels:
        cid = f"pctv-{ch['number']}"
        ce = ET.SubElement(tv, "channel", {"id": cid})
        ET.SubElement(ce, "display-name").text = f"{ch['number']} {ch['name']}"
    for ch in channels:
        cid = f"pctv-{ch['number']}"
        for row in db.list_schedule(ch["id"], start, end):
            pe = ET.SubElement(
                tv,
                "programme",
                {
                    "start": _xmltv_time(row["start_utc"]),
                    "stop": _xmltv_time(row["end_utc"]),
                    "channel": cid,
                },
            )
            ET.SubElement(pe, "title").text = row["title"]
            if row.get("year"):
                ET.SubElement(pe, "date").text = str(row["year"])
            if row.get("row_type") == "filler":
                ET.SubElement(pe, "category").text = "Filler"
                if row.get("next_title"):
                    ET.SubElement(pe, "desc").text = f"Next program: {row['next_title']}"
            elif row.get("row_type") == "commercial" or row.get("is_commercial"):
                ET.SubElement(pe, "category").text = "Commercial"
            else:
                for genre in row.get("genres") or []:
                    ET.SubElement(pe, "category").text = genre
                if row.get("series_name"):
                    ET.SubElement(pe, "sub-title").text = row["series_name"]
    body = ET.tostring(tv, encoding="utf-8", xml_declaration=True)
    return body.decode("utf-8")
