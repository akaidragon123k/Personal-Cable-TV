from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .availability import is_channel_active
from .categories import GUIDE_CATEGORIES


def _aware_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _tz(tz_name: str):
    try:
        return ZoneInfo(tz_name)
    except Exception:
        return timezone.utc


def build_guide_model(
    db,
    category: str,
    start: datetime,
    end: datetime,
    now: datetime,
    tz_name: str,
) -> dict:
    if category not in GUIDE_CATEGORIES:
        raise ValueError(f"Unknown guide category: {category}")

    start = _aware_utc(start)
    end = _aware_utc(end)
    now = _aware_utc(now)
    max_end = start + timedelta(hours=3)
    if end <= start or end > max_end:
        end = max_end
    tz = _tz(tz_name)

    channels = []
    for channel in sorted(db.list_channels(enabled_only=True), key=lambda row: int(row["number"])):
        if not is_channel_active(channel, now, tz_name):
            continue
        guide_category = db.get_channel_guide_category(channel) or "Personal Cable TV"
        if category == "Seasonal":
            if not channel.get("seasonal_enabled"):
                continue
        elif category != "All Channels" and guide_category != category:
            continue

        programs = []
        for row in db.list_schedule(channel["id"], start, end):
            row_start = _aware_utc(datetime.fromisoformat(row["start_utc"]))
            row_end = _aware_utc(datetime.fromisoformat(row["end_utc"]))
            programs.append({
                "id": row.get("id"),
                "title": row.get("title") or "Untitled",
                "row_type": row.get("row_type") or ("commercial" if row.get("is_commercial") else "content"),
                "next_title": row.get("next_title"),
                "start_utc": row_start.isoformat(),
                "end_utc": row_end.isoformat(),
                "start_local": row_start.astimezone(tz).strftime("%-I:%M %p"),
                "end_local": row_end.astimezone(tz).strftime("%-I:%M %p"),
                "left_minutes": (row_start - start).total_seconds() / 60.0,
                "duration_minutes": (row_end - row_start).total_seconds() / 60.0,
                "is_current": row_start <= now < row_end,
            })
        channels.append({
            "id": int(channel["id"]),
            "number": int(channel["number"]),
            "name": str(channel["name"]),
            "guide_category": guide_category,
            "seasonal": bool(channel.get("seasonal_enabled")),
            "programs": programs,
        })

    slots = []
    slot = start
    while slot <= end:
        slots.append({
            "utc": slot.isoformat(),
            "label": slot.astimezone(tz).strftime("%-I:%M %p"),
            "left_minutes": (slot - start).total_seconds() / 60.0,
        })
        slot += timedelta(minutes=30)

    return {
        "category": category,
        "categories": GUIDE_CATEGORIES,
        "start_utc": start.isoformat(),
        "end_utc": end.isoformat(),
        "window_minutes": (end - start).total_seconds() / 60.0,
        "now_left_minutes": (now - start).total_seconds() / 60.0,
        "time_slots": slots,
        "channels": channels,
    }
