from __future__ import annotations

PRESETS = {
    "all_movies": "All Movies",
    "horror": "Horror",
    "christmas": "Christmas",
    "halloween": "Halloween / Horror",
    "marvel": "Marvel",
    "dc": "DC",
    "family": "Family",
    "action": "Action",
    "comedy": "Comedy",
    "drama": "Drama",
    "cartoons": "Cartoons",
    "tv": "TV Shows",
    "anime": "Anime",
    "all": "Everything except commercials",
}


def _has(values, wanted: str) -> bool:
    wanted = wanted.casefold()
    return any(str(v).casefold() == wanted for v in values or [])


def matches_preset(item: dict, preset: str) -> bool:
    kind = item.get("kind")
    genres = item.get("genres") or []
    tags = item.get("tags") or []
    if kind == "commercial":
        return False
    if preset == "all":
        return True
    if preset == "all_movies":
        return kind == "movie"
    if preset == "horror":
        return kind == "movie" and _has(genres, "Horror")
    if preset == "christmas":
        return kind == "movie" and _has(tags, "Christmas")
    if preset == "halloween":
        return kind == "movie" and (_has(tags, "Halloween") or _has(genres, "Horror"))
    if preset == "marvel":
        return kind == "movie" and _has(tags, "Marvel")
    if preset == "dc":
        return kind == "movie" and _has(tags, "DC")
    if preset == "family":
        return kind == "movie" and _has(genres, "Family")
    if preset in {"action", "comedy", "drama"}:
        return kind == "movie" and _has(genres, preset.title())
    if preset == "cartoons":
        return kind == "cartoon"
    if preset == "tv":
        return kind == "episode"
    if preset == "anime":
        return kind == "anime"
    return False
