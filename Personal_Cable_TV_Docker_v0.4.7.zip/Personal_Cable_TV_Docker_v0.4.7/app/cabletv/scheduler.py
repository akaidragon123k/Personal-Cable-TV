from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from .full_filters import matches_full_filter
from .presets import matches_preset


class Scheduler:
    def __init__(self, db, tz_name: str = "UTC"):
        self.db = db
        try:
            self.tz = ZoneInfo(tz_name)
        except Exception:
            self.tz = timezone.utc

    @staticmethod
    def _time_in_rule(hhmm: str, start: str, end: str) -> bool:
        if start <= end:
            return start <= hhmm <= end
        return hhmm >= start or hhmm <= end

    @staticmethod
    def _date_in_rule(date_str: str, date_start: str | None, date_end: str | None) -> bool:
        if date_start and date_str < date_start:
            return False
        if date_end and date_str > date_end:
            return False
        return True

    def _rule_matches(self, rule: dict, local_dt: datetime) -> bool:
        days = rule.get("days") or []
        if days and local_dt.weekday() not in days:
            return False
        if not self._date_in_rule(local_dt.date().isoformat(), rule.get("date_start"), rule.get("date_end")):
            return False
        hhmm = local_dt.strftime("%H:%M")
        return self._time_in_rule(hhmm, rule["start_time"], rule["end_time"])

    def preset_at(self, channel_id: int, at: datetime) -> str:
        channel = self.db.get_channel(channel_id)
        if not channel:
            raise KeyError(f"Unknown channel {channel_id}")
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        local = at.astimezone(self.tz)
        for rule in self.db.list_rules(channel_id):
            if self._rule_matches(rule, local):
                return rule["preset"]
        return channel["default_preset"]


    def next_preset_change(self, channel_id: int, at: datetime, limit: datetime | None = None) -> datetime | None:
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        at = at.astimezone(timezone.utc)
        if limit is not None and limit.tzinfo is None:
            limit = limit.replace(tzinfo=timezone.utc)
        if limit is not None:
            limit = limit.astimezone(timezone.utc)

        rules = self.db.list_rules(channel_id)
        if not rules:
            return limit

        current = self.preset_at(channel_id, at)
        local_start = at.astimezone(self.tz)
        local_limit = (limit or (at + timedelta(days=8))).astimezone(self.tz)
        days = max(2, (local_limit.date() - local_start.date()).days + 2)
        candidates: set[datetime] = set()

        def parse_hhmm(value: str) -> tuple[int, int]:
            h, m = value.split(":", 1)
            return int(h), int(m)

        for day_offset in range(-1, days + 1):
            d = local_start.date() + timedelta(days=day_offset)
            for rule in rules:
                sh, sm = parse_hhmm(rule["start_time"])
                eh, em = parse_hhmm(rule["end_time"])
                start_local = datetime(d.year, d.month, d.day, sh, sm, tzinfo=self.tz)
                # End times are inclusive in rule matching, so the effective
                # boundary is the next minute.
                end_local = datetime(d.year, d.month, d.day, eh, em, tzinfo=self.tz) + timedelta(minutes=1)
                candidates.add(start_local.astimezone(timezone.utc))
                candidates.add(end_local.astimezone(timezone.utc))

        for candidate in sorted(c for c in candidates if c > at):
            if limit is not None and candidate >= limit:
                return limit
            if self.preset_at(channel_id, candidate) != current:
                return candidate
        return limit

    @staticmethod
    def _iso(dt: datetime) -> str:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat()

    def next_half_hour(self, value: datetime) -> datetime:
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        local = value.astimezone(self.tz)
        if local.minute in (0, 30) and local.second == 0 and local.microsecond == 0:
            return local.astimezone(timezone.utc)
        if local.minute < 30:
            aligned = local.replace(minute=30, second=0, microsecond=0)
        else:
            aligned = (local + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
        return aligned.astimezone(timezone.utc)

    @staticmethod
    def _sort_key(m: dict):
        if m.get("series_name"):
            return (
                0, str(m.get("series_name") or "").casefold(),
                int(m.get("season_number") or 0), int(m.get("episode_number") or 0),
                str(m.get("title") or "").casefold(), int(m["id"]),
            )
        return (1, str(m.get("title") or "").casefold(), 0, 0, "", int(m["id"]))

    def _build_media_snapshot(self) -> dict:
        media = self.db.list_media()
        test_media: list[dict] = []
        commercials: list[dict] = []
        full_by_library: dict[str, list[dict]] = {}
        for item in media:
            source_mode = item.get("source_mode")
            if source_mode == "test":
                test_media.append(item)
                if item.get("kind") == "commercial" and int(item.get("duration_seconds") or 0) > 0:
                    commercials.append(item)
            elif source_mode == "full" and item.get("playable"):
                library_id = str(item.get("jellyfin_library_id") or "")
                if library_id:
                    full_by_library.setdefault(library_id, []).append(item)
        return {
            "test_media": test_media,
            "commercials": commercials,
            "full_by_library": full_by_library,
        }

    def rebuild_channel(
        self,
        channel_id: int,
        start: datetime,
        end: datetime,
        media_snapshot: dict | None = None,
    ) -> int:
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        start = start.astimezone(timezone.utc)
        end = end.astimezone(timezone.utc)
        channel = self.db.get_channel(channel_id)
        if not channel:
            raise KeyError(f"Unknown channel {channel_id}")
        snapshot = media_snapshot or self._build_media_snapshot()
        test_media = snapshot["test_media"]
        commercials = snapshot["commercials"]

        full_candidates: list[dict] | None = None
        if channel.get("source_mode") == "full":
            library_id = str(channel.get("source_library_id") or "")
            full_candidates = [
                m for m in snapshot["full_by_library"].get(library_id, [])
                if int(m.get("duration_seconds") or 0) > 0 and matches_full_filter(m, channel.get("filter"))
            ]
            full_candidates.sort(key=self._sort_key)

        content_index_by_preset: dict[str, int] = {}
        test_candidates_by_preset: dict[str, list[dict]] = {}
        max_duration_by_preset: dict[str, int] = {}
        full_max_duration = max((int(m.get("duration_seconds") or 0) for m in (full_candidates or [])), default=0)
        commercial_index = 0
        pending_rows: list[dict] = []

        def candidates_at(at: datetime) -> tuple[str, list[dict], datetime, int]:
            if channel.get("source_mode") == "full":
                return "__full__", full_candidates or [], end, full_max_duration
            preset = self.preset_at(channel_id, at)
            if preset not in test_candidates_by_preset:
                preset_candidates = [
                    m for m in test_media
                    if int(m.get("duration_seconds") or 0) > 0 and matches_preset(m, preset)
                ]
                preset_candidates.sort(key=self._sort_key)
                test_candidates_by_preset[preset] = preset_candidates
                max_duration_by_preset[preset] = max(
                    (int(m.get("duration_seconds") or 0) for m in preset_candidates), default=0
                )
            return (
                preset,
                test_candidates_by_preset[preset],
                self.next_preset_change(channel_id, at, end) or end,
                max_duration_by_preset[preset],
            )

        def choose_content(at: datetime, advance: bool) -> tuple[dict | None, str | None]:
            preset, candidates, boundary, max_duration = candidates_at(at)
            if not candidates:
                return None, preset
            selected = candidates
            if boundary > at:
                remaining = int((boundary - at).total_seconds())
                # Most schedule positions have room for every candidate. Avoid
                # rescanning a large library on every program selection; only
                # build a fitting subset when the rule/window boundary is close.
                if max_duration > remaining:
                    fitting = [m for m in candidates if int(m["duration_seconds"]) <= remaining]
                    if fitting:
                        selected = fitting
            index = content_index_by_preset.get(preset, 0) % len(selected)
            item = selected[index]
            if advance:
                content_index_by_preset[preset] = content_index_by_preset.get(preset, 0) + 1
            return item, preset

        cursor = start
        first_main = self.next_half_hour(cursor)
        if first_main > cursor:
            next_item, _ = choose_content(first_main, advance=False)
            pending_rows.append({
                "media_id": None,
                "start_utc": self._iso(cursor),
                "end_utc": self._iso(first_main),
                "row_type": "filler",
                "next_title": next_item.get("title") if next_item else None,
            })
            cursor = first_main

        while cursor < end:
            item, preset = choose_content(cursor, advance=True)
            if not item:
                # Preserve continuous coverage when a daypart has no eligible content.
                next_boundary = self.next_half_hour(cursor + timedelta(microseconds=1))
                if next_boundary <= cursor:
                    next_boundary = cursor + timedelta(minutes=30)
                pending_rows.append({
                    "media_id": None,
                    "start_utc": self._iso(cursor),
                    "end_utc": self._iso(next_boundary),
                    "row_type": "filler",
                    "next_title": None,
                })
                cursor = next_boundary
                continue

            item_end = cursor + timedelta(seconds=int(item["duration_seconds"]))
            pending_rows.append({
                "media_id": int(item["id"]),
                "start_utc": self._iso(cursor),
                "end_utc": self._iso(item_end),
                "row_type": "content",
                "next_title": None,
            })
            cursor = item_end
            if cursor >= end:
                break

            next_boundary = self.next_half_hour(cursor)
            if next_boundary <= cursor:
                next_boundary = cursor
            next_item, _ = choose_content(next_boundary, advance=False) if next_boundary < end else (None, None)

            if next_boundary > cursor and channel["commercials_enabled"] and commercials:
                attempts = 0
                while attempts < len(commercials):
                    ad = commercials[commercial_index % len(commercials)]
                    commercial_index += 1
                    attempts += 1
                    ad_seconds = int(ad.get("duration_seconds") or 0)
                    if ad_seconds <= 0:
                        continue
                    ad_end = cursor + timedelta(seconds=ad_seconds)
                    if ad_end > next_boundary:
                        continue
                    pending_rows.append({
                        "media_id": int(ad["id"]),
                        "start_utc": self._iso(cursor),
                        "end_utc": self._iso(ad_end),
                        "row_type": "commercial",
                        "next_title": None,
                    })
                    cursor = ad_end
                    if cursor >= next_boundary:
                        break

            if next_boundary > cursor:
                pending_rows.append({
                    "media_id": None,
                    "start_utc": self._iso(cursor),
                    "end_utc": self._iso(next_boundary),
                    "row_type": "filler",
                    "next_title": next_item.get("title") if next_item else None,
                })
                cursor = next_boundary

        self.db.replace_schedule_rows(channel_id, pending_rows)
        return len(pending_rows)

    def ensure_all_channels(self, start: datetime | None = None, hours: int = 72) -> None:
        start = start or datetime.now(timezone.utc)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        # Anchor to UTC midnight so restarts create the same lineup for the same day.
        anchor = start.astimezone(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        end = anchor + timedelta(hours=hours)
        media_snapshot = self._build_media_snapshot()
        for channel in self.db.list_channels(enabled_only=True):
            self.rebuild_channel(channel["id"], anchor, end, media_snapshot=media_snapshot)

    def current_program(self, channel_id: int, at: datetime | None = None) -> dict | None:
        at = at or datetime.now(timezone.utc)
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        at = at.astimezone(timezone.utc)
        row = self.db.schedule_at(channel_id, self._iso(at))
        if not row:
            return None
        start = datetime.fromisoformat(row["start_utc"])
        row["offset_seconds"] = max(0.0, (at - start).total_seconds())
        return row
