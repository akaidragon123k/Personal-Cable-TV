from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import docker

HOST = os.getenv("UPDATER_HOST", "0.0.0.0")
PORT = int(os.getenv("UPDATER_PORT", "8787"))
CONTAINER_NAME = os.getenv("PCTV_CONTAINER_NAME", "personal-cable-tv")
MANIFEST_URL = os.getenv(
    "PCTV_UPDATE_MANIFEST_URL",
    "https://raw.githubusercontent.com/akaidragon123k/Personal-Cable-TV/main/updates/manifest.json",
)
ALLOWED_IMAGE_PREFIX = os.getenv(
    "PCTV_ALLOWED_IMAGE_PREFIX",
    "ghcr.io/akaidragon123k/personal-cable-tv:",
)
HEALTH_URL = os.getenv("PCTV_HEALTH_URL", "http://personal-cable-tv:8484/health")

_lock = threading.Lock()
_state = {"running": False, "message": "Idle", "last_result": None}


def _fetch_manifest() -> dict:
    req = urllib.request.Request(MANIFEST_URL, headers={"User-Agent": "Personal-Cable-TV-Updater/1"})
    with urllib.request.urlopen(req, timeout=10) as response:
        data = json.loads(response.read().decode("utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError("Update manifest is invalid")
    return data


def _release_for_version(manifest: dict, requested_version: str) -> dict:
    releases = manifest.get("releases")
    if not isinstance(releases, list):
        raise RuntimeError("Update manifest does not contain a release list")
    for release in releases:
        if not isinstance(release, dict):
            continue
        version = str(release.get("version") or "").strip()
        if version != requested_version:
            continue
        image = str(release.get("image") or "").strip()
        if not image:
            raise RuntimeError("Update manifest is missing the image for this release")
        if not image.startswith(ALLOWED_IMAGE_PREFIX):
            raise RuntimeError("Update image is not from the approved Personal Cable TV registry")
        return release
    raise RuntimeError("Requested release is not published in the stable update manifest")


def _port_bindings(host_config: dict) -> dict:
    result = {}
    for container_port, bindings in (host_config.get("PortBindings") or {}).items():
        if not bindings:
            result[container_port] = None
            continue
        converted = []
        for binding in bindings:
            host_ip = binding.get("HostIp") or ""
            host_port = binding.get("HostPort") or ""
            if host_ip:
                converted.append((host_ip, int(host_port) if host_port else None))
            else:
                converted.append(int(host_port) if host_port else None)
        result[container_port] = converted[0] if len(converted) == 1 else converted
    return result


def _volumes(mounts: list[dict]) -> dict:
    result = {}
    for mount in mounts:
        if mount.get("Type") not in {"bind", "volume"}:
            continue
        source = mount.get("Source") or mount.get("Name")
        destination = mount.get("Destination")
        if not source or not destination:
            continue
        mode = "rw" if mount.get("RW", False) else "ro"
        result[source] = {"bind": destination, "mode": mode}
    return result


def _wait_healthy(client: docker.DockerClient, container, timeout: int = 60) -> None:
    deadline = time.time() + timeout
    last = "starting"
    while time.time() < deadline:
        container.reload()
        state = container.attrs.get("State") or {}
        if not state.get("Running"):
            raise RuntimeError(f"Updated container stopped unexpectedly: {state.get('Error') or 'unknown error'}")
        health = (state.get("Health") or {}).get("Status")
        if health:
            last = health
            if health == "healthy":
                return
            if health == "unhealthy":
                raise RuntimeError("Updated container reported unhealthy")
        else:
            try:
                with urllib.request.urlopen(HEALTH_URL, timeout=3) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                if response.status == 200 and payload.get("status") == "ok":
                    return
            except Exception:
                pass
        time.sleep(2)
    raise RuntimeError(f"Timed out waiting for updated container health ({last})")


def _perform_update(requested_version: str) -> None:
    backup_name = None
    old = None
    network_records = []
    client = None
    try:
        client = docker.from_env()
        manifest = _fetch_manifest()
        release = _release_for_version(manifest, requested_version)
        image = release["image"]
        version = release["version"]
        _state.update(message=f"Pulling Personal Cable TV {version}…")
        client.images.pull(image)

        old = client.containers.get(CONTAINER_NAME)
        old.reload()
        attrs = old.attrs
        config = attrs.get("Config") or {}
        host_config = attrs.get("HostConfig") or {}
        mounts = attrs.get("Mounts") or []
        networks = ((attrs.get("NetworkSettings") or {}).get("Networks") or {}).copy()

        _state.update(message="Stopping current Personal Cable TV safely…")
        old.stop(timeout=15)

        # Disconnect the stopped container so its DNS alias cannot conflict with the replacement.
        for network_name, endpoint in networks.items():
            try:
                network = client.networks.get(network_name)
                network_records.append((network, endpoint))
                network.disconnect(old, force=True)
            except Exception:
                pass

        backup_name = f"{CONTAINER_NAME}-rollback-{int(time.time())}"
        old.rename(backup_name)

        network_name = next(iter(networks), None)
        kwargs = {
            "image": image,
            "name": CONTAINER_NAME,
            "detach": True,
            "environment": config.get("Env") or [],
            "labels": config.get("Labels") or {},
            "ports": _port_bindings(host_config),
            "volumes": _volumes(mounts),
            "read_only": bool(host_config.get("ReadonlyRootfs")),
            "restart_policy": host_config.get("RestartPolicy") or {"Name": "unless-stopped"},
        }
        if host_config.get("Tmpfs"):
            kwargs["tmpfs"] = host_config["Tmpfs"]
        if host_config.get("CapDrop"):
            kwargs["cap_drop"] = host_config["CapDrop"]
        if host_config.get("SecurityOpt"):
            kwargs["security_opt"] = host_config["SecurityOpt"]
        if host_config.get("PidsLimit"):
            kwargs["pids_limit"] = host_config["PidsLimit"]
        if network_name:
            kwargs["network"] = network_name

        _state.update(message=f"Starting Personal Cable TV {version}…")
        new = client.containers.create(**kwargs)
        new.start()
        _wait_healthy(client, new)

        if old:
            try:
                old.remove(force=True)
            except Exception:
                pass
        _state.update(
            running=False,
            message=f"Personal Cable TV {version} installed successfully.",
            last_result={"ok": True, "version": version},
        )
    except Exception as exc:
        # Roll back automatically if the replacement cannot become healthy.
        try:
            if client:
                try:
                    failed = client.containers.get(CONTAINER_NAME)
                    failed.remove(force=True)
                except Exception:
                    pass
                if old is not None:
                    old.reload()
                    if backup_name:
                        old.rename(CONTAINER_NAME)
                    for network, endpoint in network_records:
                        try:
                            aliases = endpoint.get("Aliases") or None
                            network.connect(old, aliases=aliases)
                        except Exception:
                            pass
                    old.start()
        except Exception:
            pass
        _state.update(
            running=False,
            message=f"Update failed and rollback was attempted: {exc}",
            last_result={"ok": False, "error": str(exc)},
        )
    finally:
        try:
            if client is not None:
                client.close()
        except Exception:
            pass
        _lock.release()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[updater] {self.address_string()} - {fmt % args}")

    def _send_json(self, status: int, payload: dict):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok", "updater": 1})
            return
        if self.path == "/status":
            self._send_json(200, dict(_state))
            return
        self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/update":
            self._send_json(404, {"error": "Not found"})
            return
        length = int(self.headers.get("Content-Length", "0") or 0)
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        except Exception:
            self._send_json(400, {"error": "Invalid update request"})
            return
        requested_version = str(payload.get("version") or "").strip()
        if not requested_version:
            self._send_json(400, {"error": "A published target version is required"})
            return
        if not _lock.acquire(blocking=False):
            self._send_json(HTTPStatus.CONFLICT, {"error": "An update is already running"})
            return
        _state.update(running=True, message=f"Update to {requested_version} requested…", last_result=None)
        threading.Thread(target=_perform_update, args=(requested_version,), name="pctv-update", daemon=True).start()
        self._send_json(HTTPStatus.ACCEPTED, {"status": "started", "version": requested_version})


if __name__ == "__main__":
    print(f"Personal Cable TV updater listening on {HOST}:{PORT}")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.daemon_threads = True
    server.serve_forever()
