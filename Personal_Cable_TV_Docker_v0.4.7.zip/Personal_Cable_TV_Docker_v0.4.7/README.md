# Personal Cable TV v0.4.7 — Docker Release

## v0.4.7 cleanup
The public interface now uses Full Library Mode as the normal Jellyfin library connection path. The obsolete Scan Test Media and Legacy Metadata Import controls have been removed. Help & Support now includes step-by-step M3U tuner and XMLTV guide setup for Jellyfin Live TV.

Personal Cable TV turns a Jellyfin library into scheduled, linear cable-style Live TV channels.

## Quick start

Extract the release into your Docker apps folder, open a terminal in that folder, and run:

    docker compose up -d --build

Then open:

    http://YOUR-NAS-IP:8484

The first build downloads the Python base image and installs FFmpeg, so it can take a little longer than later starts.

## Connect Jellyfin

After Personal Cable TV opens, use the **Jellyfin** section to enter your Jellyfin URL and API key, save the settings, and sync your library. Full Library Mode requests library and playback information through Jellyfin; it does not require your real NAS media folders to be mounted into Personal Cable TV.

## Persistent data

The Compose file stores the application database in:

    ./data

Keep that folder when updating or recreating the container. Do not publish your own populated `data` folder because it can contain saved Personal Cable TV settings, including Jellyfin connection settings.

## Live TV feeds

After channels exist, add these URLs to Jellyfin Live TV using the IP address of the machine running Personal Cable TV:

    M3U:   http://YOUR-NAS-IP:8484/iptv/channels.m3u
    XMLTV: http://YOUR-NAS-IP:8484/iptv/guide.xml

## Useful Docker commands

Start/build:

    docker compose up -d --build

Check status:

    docker compose ps

View recent logs:

    docker compose logs --tail=100 personal-cable-tv

Stop:

    docker compose down

Start again without rebuilding:

    docker compose up -d

## Optional port/time-zone settings

The default web port is `8484`. To use another host port, create a `.env` file beside `docker-compose.yml`:

    PCTV_PORT=8485

You can also set your time zone:

    TZ=America/Los_Angeles

If `TZ` is not set, the container defaults to UTC.

## Safety

This public Compose file intentionally uses a relative `./data` app-data mount only. It does not mount `/DATA`, `/`, `/var/run/docker.sock`, or your real Jellyfin media folders. The container root filesystem remains read-only and Linux capabilities are dropped.

## Jellyfin Companion

Personal Cable TV works without the optional Companion. The Companion is for the enhanced Personal Cable TV interface inside supported Jellyfin clients, including Jellyfin Web/LG webOS. Roku-specific enhanced support is being developed separately.

## Version

This package contains the accepted Personal Cable TV **v0.4.7** application code. The Docker packaging is simplified for new installs and uses relative paths so users do not need the NAS-specific upgrade procedure used during development/testing.
