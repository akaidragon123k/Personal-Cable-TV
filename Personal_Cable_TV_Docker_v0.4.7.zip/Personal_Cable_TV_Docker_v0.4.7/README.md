# Personal Cable TV v0.4.7 — Docker Release

Personal Cable TV turns a Jellyfin library into scheduled, linear cable-style Live TV channels.

This v0.4.7 package is also the **starting point for the Personal Cable TV in-app Docker update system**. Users who install this package can later move through newer public releases from the Personal Cable TV Settings page instead of replacing the whole Docker package manually.

## What v0.4.7 includes

- Full Library Mode as the normal Jellyfin library connection path
- Obsolete Scan Test Media and Legacy Metadata Import controls removed
- Step-by-step M3U tuner and XMLTV guide setup in Help & Support
- New **Settings → Personal Cable TV Updates** section
- User-confirmed Docker updates — never automatic
- Staged version order so published releases can be installed in sequence
- Automatic rollback attempt if a replacement app container does not become healthy

## Quick start

Extract the release into your Docker apps folder, open a terminal in that folder, and run:

    docker compose up -d

Then open:

    http://YOUR-NAS-IP:8484

Both the Personal Cable TV image and the small updater sidecar are pulled from GitHub Container Registry.

## Connect Jellyfin

After Personal Cable TV opens, use the **Jellyfin** section to enter your Jellyfin URL and API key, save the settings, and sync your library. Full Library Mode requests library and playback information through Jellyfin; it does not require your real NAS media folders to be mounted into Personal Cable TV.

## In-app Docker updates

After this v0.4.7 package is installed:

1. Open **Settings** in Personal Cable TV.
2. Find **Personal Cable TV Updates**.
3. Press **Check for Updates**.
4. If a newer public release is available, review the displayed target version.
5. Press **Update Personal Cable TV** and confirm.

Updates are deliberately staged. If 0.4.7, 0.5.2, and 0.5.3 are all published, the updater can offer the next published version in order rather than forcing a jump over an intermediate release.

The update process preserves the existing application-data mount, port mappings, and media mounts. The replacement container must become healthy before the previous container is discarded. If health verification fails, the updater attempts to restore the previous container automatically.

### Why there is an updater sidecar

Docker containers cannot safely replace themselves without access to the Docker host. Personal Cable TV therefore keeps Docker control out of the main application container.

A separate `pctv-updater` sidecar receives `/var/run/docker.sock` and performs the container replacement. Its HTTP port is **not published to the LAN**; it is reachable only on the private Compose network. It validates update targets against the official Personal Cable TV update manifest and only accepts images from:

    ghcr.io/akaidragon123k/personal-cable-tv

Access to the Docker socket is powerful. Users should install the package only on a Docker host they control and should not expose the updater container directly to untrusted networks.

## Persistent data

The Compose file stores the application database in:

    ./data

Keep that folder when updating or recreating the container. Do not publish your own populated `data` folder because it can contain saved Personal Cable TV settings, including Jellyfin connection settings.

## Live TV feeds

After channels exist, add these URLs to Jellyfin Live TV using the IP address of the machine running Personal Cable TV:

    M3U:   http://YOUR-NAS-IP:8484/iptv/channels.m3u
    XMLTV: http://YOUR-NAS-IP:8484/iptv/guide.xml

## Useful Docker commands

First install/start:

    docker compose up -d

Check status:

    docker compose ps

View recent app logs:

    docker compose logs --tail=100 personal-cable-tv

View updater logs:

    docker compose logs --tail=100 pctv-updater

Stop both containers:

    docker compose down

Start again:

    docker compose up -d

### Manual update fallback

If the in-app updater is unavailable, the public `stable` image can be refreshed manually:

    docker compose pull personal-cable-tv
    docker compose up -d personal-cable-tv

Do not delete the `./data` folder during an update.

## Optional port/time-zone settings

The default web port is `8484`. To use another host port, create a `.env` file beside `docker-compose.yml`:

    PCTV_PORT=8485

You can also set your time zone:

    TZ=America/Los_Angeles

If `TZ` is not set, the container defaults to UTC.

## Media and data safety

The **main Personal Cable TV container** uses only the relative `./data` writable app-data mount in this public package. Its root filesystem remains read-only and Linux capabilities are dropped.

The **updater sidecar** mounts the Docker socket because Docker access is required to replace the Personal Cable TV app container. It does not receive a media mount. During an update it preserves the app container's existing mounts rather than replacing media files.

Personal Cable TV is designed not to delete, rename, move, or overwrite user media.

## Jellyfin Companion

Personal Cable TV works without the optional Companion. The Companion is for the enhanced Personal Cable TV interface inside supported Jellyfin clients.

Companion repository:

https://github.com/akaidragon123k/PersonalCableTV-Jellyfin-Companion

## Version

This package remains **Personal Cable TV v0.4.7**. The updater foundation does not change the application version number; it prepares v0.4.7 users to receive later public versions when those versions are published.
