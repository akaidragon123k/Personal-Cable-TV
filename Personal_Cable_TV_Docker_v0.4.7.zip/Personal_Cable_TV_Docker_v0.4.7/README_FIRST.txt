PERSONAL CABLE TV v0.4.7 - DOCKER START + IN-APP UPDATES
===========================================================

This package is for a NEW Docker install.
It does NOT contain anyone's database, Jellyfin API key, or media files.

START
1. Extract this folder anywhere you keep Docker apps.
2. Open a terminal in this folder.
3. Run:

   docker compose up -d

4. Open in a browser:

   http://YOUR-NAS-IP:8484

5. In Personal Cable TV, open Jellyfin and enter your Jellyfin URL + API key.

That is all that is required to start the app.

UPDATES
- Open Settings -> Personal Cable TV Updates.
- Press Check for Updates.
- If a newer public release is available, press Update Personal Cable TV and confirm.
- Updates are NEVER installed automatically.
- Releases are offered in the published order. Example: 0.4.7 -> 0.5.2 -> 0.5.3.
- The updater keeps your existing ./data mount and existing media-mount safety rules.
- If a new container cannot become healthy, the updater automatically attempts rollback.

IMPORTANT UPDATE SECURITY NOTE
- The main Personal Cable TV container does NOT receive the Docker socket.
- A separate private updater sidecar uses /var/run/docker.sock so it can replace only the Personal Cable TV app container.
- The updater port is not published to your LAN.
- It accepts only Personal Cable TV images from ghcr.io/akaidragon123k/personal-cable-tv.

DATA
- Your Personal Cable TV database is stored in the local ./data folder.
- Keep ./data when updating or recreating the container.
- Do not share ./data on GitHub because it can contain saved settings.

STOP
   docker compose down

START AGAIN
   docker compose up -d

STATUS
   docker compose ps

LOGS
   docker compose logs --tail=100 personal-cable-tv

DEFAULT PORT
8484

If 8484 is already used, create a .env file beside docker-compose.yml and add:
PCTV_PORT=8485

MEDIA SAFETY
- Full Library Mode talks to Jellyfin; it does not need your real media folders mounted into the main container.
- The Personal Cable TV main container root filesystem is read-only; only ./data is writable app data.
- The updater preserves existing mounts during an update and does not delete, rename, move, or overwrite media.

V0.4.7 UPDATE FOUNDATION
- Adds Settings -> Personal Cable TV Updates.
- Adds user-confirmed staged Docker updates.
- Adds rollback protection when an updated app container does not become healthy.
- Help & Support documents the updater and Docker-socket requirement.
- Scan Test Media remains removed.
- Legacy Metadata Import remains removed.
- Full Library Mode remains the normal Jellyfin connection path.
