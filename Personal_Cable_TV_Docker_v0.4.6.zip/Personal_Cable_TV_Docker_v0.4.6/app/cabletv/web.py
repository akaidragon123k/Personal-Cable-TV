from __future__ import annotations

import html
import json
import os
import socket
import sqlite3
import threading
import time
import urllib.parse
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import __version__
from .availability import is_channel_active
from .db import Database
from .feeds import build_m3u, build_xmltv
from .filler import iter_filler_mpegts
from .full_sync import FullLibrarySyncService
from .guide import build_guide_model
from .categories import GUIDE_CATEGORIES, PERSISTED_SOURCE_CATEGORIES
from .jellyfin import JellyfinClient, JellyfinMetadataImporter
from .jellyfin_streamer import JellyfinPlaybackAdapter, JellyfinPlaybackError
from .presets import PRESETS
from .scanner import MediaSafetyError, MediaScanner
from .scheduler import Scheduler
from .streamer import stream_channel_bytes
from .suggestions import SuggestionEngine


class CableTVApplication:
    def __init__(
        self,
        data_dir: str | Path,
        media_root: str | Path,
        tz_name: str = "UTC",
        allow_writable_media: bool = False,
        stream_mode: str = "copy",
        public_base_url: str | None = None,
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.media_root = Path(media_root)
        self.tz_name = tz_name
        self.allow_writable_media = allow_writable_media
        self.stream_mode = stream_mode if stream_mode in {"copy", "transcode"} else "copy"
        self.public_base_url = public_base_url.rstrip("/") if public_base_url else None
        self.db = Database(self.data_dir / "cabletv.sqlite3")
        self.db.initialize()
        self.scanner = MediaScanner(self.media_root, allow_writable_media=allow_writable_media)
        self.scheduler = Scheduler(self.db, tz_name=tz_name)
        self.full_sync = FullLibrarySyncService(self.db)
        self.suggestions = SuggestionEngine(self.db)
        self.jellyfin_playback = None
        self._guide_cache_lock = threading.Lock()
        self._guide_cache_xml: str | None = None
        self._guide_cache_expires_at = 0.0
        self._schedule_rebuild_lock = threading.Lock()

    def save_full_library_settings(self, form: dict[str, str | list[str]]) -> None:
        url = str(form.get("url") or "").strip().rstrip("/")
        api_key = str(form.get("api_key") or "").strip()
        if not url:
            raise ValueError("Jellyfin URL is required")
        if not api_key:
            api_key = self.db.get_setting("full_jellyfin_api_key", "") or ""
        if not api_key:
            raise ValueError("Jellyfin API key is required")
        self.db.set_setting("full_jellyfin_url", url)
        self.db.set_setting("full_jellyfin_api_key", api_key)

    def full_library_credentials(self) -> tuple[str, str]:
        url = (self.db.get_setting("full_jellyfin_url", "") or "").strip()
        api_key = (self.db.get_setting("full_jellyfin_api_key", "") or "").strip()
        if not url or not api_key:
            raise ValueError("Configure Jellyfin Full Library settings first")
        return url, api_key

    def sync_full_library(self) -> dict:
        url, api_key = self.full_library_credentials()
        result = self.full_sync.sync(url, api_key)
        self.rebuild_schedules()
        return result

    def auto_create_full_channels(self) -> dict:
        result = self.suggestions.create_all_eligible()
        self.rebuild_schedules()
        return result

    def create_suggested_full_channel(self, form: dict[str, str | list[str]]) -> dict:
        library_id = str(form.get("source_library_id") or "").strip()
        raw_filter = str(form.get("filter_json") or "").strip()
        if not library_id or not raw_filter:
            raise ValueError("Source library and suggestion filter are required")
        try:
            filter_spec = json.loads(raw_filter)
        except json.JSONDecodeError as exc:
            raise ValueError("Invalid suggestion filter") from exc
        if not isinstance(filter_spec, dict):
            raise ValueError("Invalid suggestion filter")
        result = self.suggestions.create_suggestion(library_id, filter_spec)
        self.rebuild_schedules()
        return result

    @staticmethod
    def _split_filter_values(value: str) -> list[str]:
        import re
        return [part.strip() for part in re.split(r"[,\n\r]+", value) if part.strip()]

    def create_custom_full_channel(self, form: dict[str, str | list[str]]) -> int:
        number = int(form.get("number") or 0)
        name = str(form.get("name") or "").strip()
        library_id = str(form.get("source_library_id") or "").strip()
        if number <= 0:
            raise ValueError("Channel number must be greater than zero")
        if not name:
            raise ValueError("Channel name is required")
        if not self.db.get_full_library(library_id):
            raise ValueError(f"Unknown source library: {library_id}")

        filter_spec: dict[str, object] = {}
        genre = str(form.get("genre") or "").strip()
        tag = str(form.get("tag") or "").strip()
        if genre:
            filter_spec["genre"] = genre
        if tag:
            filter_spec["tag"] = tag
        for field in ("year_min", "year_max"):
            raw = str(form.get(field) or "").strip()
            if raw:
                filter_spec[field] = int(raw)
        if "year_min" in filter_spec and "year_max" in filter_spec and int(filter_spec["year_min"]) > int(filter_spec["year_max"]):
            raise ValueError("Minimum year cannot be after maximum year")
        keywords = self._split_filter_values(str(form.get("title_keywords") or ""))
        item_ids = self._split_filter_values(str(form.get("item_ids") or ""))
        if keywords:
            filter_spec["title_keywords"] = keywords
        if item_ids:
            filter_spec["item_ids"] = item_ids
        commercials = str(form.get("commercials_enabled", "0")).lower() in {"1", "true", "on", "yes"}
        channel_id = self.db.create_full_channel(
            number=number,
            name=name,
            source_library_id=library_id,
            filter_spec=filter_spec,
            commercials_enabled=commercials,
            auto_created=False,
        )
        self.rebuild_schedules()
        return channel_id

    def allowed_media_roots(self) -> list[Path]:
        # Test Mode is the only direct-file playback path in v0.4.2.
        return [self.media_root]

    def stream_channel(self, channel_id: int):
        now = datetime.now(timezone.utc)
        current = self.scheduler.current_program(channel_id, now)
        if not current:
            self.scheduler.ensure_all_channels(now, hours=96)
            current = self.scheduler.current_program(channel_id, now)
        if not current:
            return iter(())

        if current.get("row_type") == "filler":
            end_at = datetime.fromisoformat(current["end_utc"])
            if end_at.tzinfo is None:
                end_at = end_at.replace(tzinfo=timezone.utc)
            remaining = max(1.0, (end_at.astimezone(timezone.utc) - now).total_seconds())
            channel = self.db.get_channel(channel_id) or {"name": f"Channel {channel_id}"}
            return iter_filler_mpegts(
                str(channel["name"]), current.get("next_title"), remaining
            )

        if current.get("source_mode") == "full":
            media = self.db.get_media(int(current["media_id"]))
            if not media:
                raise JellyfinPlaybackError("Scheduled Jellyfin item is missing")
            adapter = self.jellyfin_playback
            if adapter is None:
                url = (self.db.get_setting("full_jellyfin_url", "") or "").strip()
                key = (self.db.get_setting("full_jellyfin_api_key", "") or "").strip()
                if not url or not key:
                    raise JellyfinPlaybackError("Configure Jellyfin Full Library settings first")
                adapter = JellyfinPlaybackAdapter(JellyfinClient(url, key))
            return adapter.iter_mpegts(media, current.get("offset_seconds", 0.0))

        return stream_channel_bytes(
            self.scheduler, channel_id, self.allowed_media_roots(), self.stream_mode
        )

    def scan_media(self) -> dict:
        items = self.scanner.scan()
        count = self.db.replace_media(items)
        self.rebuild_schedules()
        return {"indexed": count}

    def rebuild_schedules(self) -> dict:
        with self._schedule_rebuild_lock:
            now = datetime.now(timezone.utc)
            anchor = now.astimezone(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            coverage_end = anchor + timedelta(hours=192)
            self.scheduler.ensure_all_channels(now, hours=192)
            self.db.set_setting("schedule_coverage_end_utc", coverage_end.isoformat())
            self.invalidate_guide_cache()
            return {"channels": len(self.db.list_channels(enabled_only=True))}

    def invalidate_guide_cache(self) -> None:
        with self._guide_cache_lock:
            self._guide_cache_xml = None
            self._guide_cache_expires_at = 0.0

    def guide_html(self, base_url: str, query: dict[str, list[str]] | None = None) -> str:
        query = query or {}
        category = (query.get("category") or ["All Channels"])[-1]
        if category not in GUIDE_CATEGORIES:
            category = "All Channels"
        now = datetime.now(timezone.utc)
        raw_start = (query.get("start") or [""])[-1].strip()
        if raw_start:
            try:
                start = datetime.fromisoformat(raw_start)
                if start.tzinfo is None:
                    start = start.replace(tzinfo=timezone.utc)
                start = start.astimezone(timezone.utc)
            except ValueError:
                start = now.replace(minute=0 if now.minute < 30 else 30, second=0, microsecond=0)
        else:
            start = now.replace(minute=0 if now.minute < 30 else 30, second=0, microsecond=0)
        end = start + timedelta(hours=3)
        model = build_guide_model(self.db, category, start, end, now, self.tz_name)

        pixels_per_minute = 6.0
        timeline_width = int(model["window_minutes"] * pixels_per_minute)
        categories = "".join(
            f'<a class="guide-category {"active" if item == category else ""}" href="/guide?category={urllib.parse.quote(item)}">{html.escape(item)}</a>'
            for item in GUIDE_CATEGORIES
        )
        slots = "".join(
            f'<div class="guide-time-label" style="left:{slot["left_minutes"] * pixels_per_minute:.1f}px">{html.escape(slot["label"])}</div>'
            for slot in model["time_slots"]
        )
        grid_lines = "".join(
            f'<div class="guide-grid-line" style="left:{slot["left_minutes"] * pixels_per_minute:.1f}px"></div>'
            for slot in model["time_slots"]
        )
        rows = []
        for channel in model["channels"]:
            blocks = []
            for program in channel["programs"]:
                visible_start = max(0.0, float(program["left_minutes"]))
                visible_end = min(
                    float(model["window_minutes"]),
                    float(program["left_minutes"]) + float(program["duration_minutes"]),
                )
                width_minutes = max(0.0, visible_end - visible_start)
                if width_minutes <= 0:
                    continue
                classes = ["guide-program", f'guide-{program["row_type"]}']
                if program["is_current"]:
                    classes.append("guide-current-program")
                time_text = f'{program["start_local"]}–{program["end_local"]}'
                blocks.append(
                    f'<div class="{" ".join(classes)}" style="left:{visible_start * pixels_per_minute:.1f}px;width:{max(12.0, width_minutes * pixels_per_minute):.1f}px" '
                    f'title="{html.escape(program["title"])} · {html.escape(time_text)}">'
                    f'<strong>{html.escape(program["title"])}</strong><small>{html.escape(time_text)}</small></div>'
                )
            rows.append(
                f'<div class="guide-row">'
                f'<div class="guide-channel" title="{html.escape(channel["name"])}"><b>{channel["number"]}</b><span>{html.escape(channel["name"])}</span><small>{html.escape(channel["guide_category"])}</small></div>'
                f'<div class="guide-track" style="width:{timeline_width}px">{grid_lines}{"".join(blocks)}</div></div>'
            )
        if not rows:
            rows.append('<div class="guide-empty">No active channels in this category.</div>')

        marker_left = max(0.0, min(float(model["window_minutes"]), float(model["now_left_minutes"]))) * pixels_per_minute
        prev_start = (start - timedelta(hours=3)).isoformat()
        next_start = (start + timedelta(hours=3)).isoformat()
        selected = urllib.parse.quote(category)
        return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Personal Cable TV Guide</title><style>
:root{{--bg:#091019;--panel:#111b28;--panel2:#182536;--line:#2a3d55;--text:#f4f8fc;--muted:#9fb1c5;--accent:#4a90e2;--button:#242c35;--button-hover:#303b47;--button-pressed:#3a4653;--current:#244d76;--filler:#303a46;--commercial:#4a3540}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif}}
.guide-head{{position:sticky;top:0;z-index:20;background:#091019f5;border-bottom:1px solid var(--line);padding:16px 20px}}
.guide-title{{display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap}}.guide-title h1{{margin:0;font-size:23px}}a{{color:#cfe6ff;text-decoration:none}}
.guide-categories{{display:flex;gap:8px;overflow-x:auto;padding-top:12px}}.guide-category{{white-space:nowrap;padding:9px 12px;border:1px solid #3a4653;border-radius:10px;background:var(--button);color:#e3e9ee;transition:background .14s ease,border-color .14s ease,transform .12s ease}}.guide-category:hover{{background:var(--button-hover);border-color:#52606f}}.guide-category:active{{background:var(--button-pressed);transform:translateY(1px)}}.guide-category.active{{background:#203a55;border-color:var(--accent);color:white;box-shadow:inset 0 -2px 0 var(--accent)}}
.guide-nav{{display:flex;gap:8px}}.guide-nav a{{padding:8px 11px;border:1px solid #3a4653;border-radius:9px;background:var(--button);color:#e3e9ee;transition:background .14s ease,border-color .14s ease,transform .12s ease}}.guide-nav a:hover{{background:var(--button-hover);border-color:#52606f}}.guide-nav a:active{{background:var(--button-pressed);transform:translateY(1px)}}
.guide-shell{{overflow:auto;position:relative}}.guide-time-row,.guide-row{{display:grid;grid-template-columns:280px max-content;min-width:max-content}}
.guide-channel-head,.guide-channel{{position:sticky;left:0;z-index:10;width:280px;background:var(--panel);border-right:1px solid var(--line);border-bottom:1px solid var(--line);padding:12px 14px}}
.guide-channel{{min-height:76px;display:grid;grid-template-columns:48px 1fr;grid-template-rows:auto auto;column-gap:10px;align-content:center}}.guide-channel b{{grid-row:1/3;font-size:22px;color:var(--accent);align-self:center}}.guide-channel span{{white-space:normal;overflow-wrap:anywhere;font-weight:700;line-height:1.2}}.guide-channel small{{color:var(--muted);margin-top:4px}}
.guide-time-track,.guide-track{{position:relative;background:#0e1722}}.guide-time-track{{height:52px;border-bottom:1px solid var(--line)}}.guide-track{{height:76px;border-bottom:1px solid var(--line)}}
.guide-time-label{{position:absolute;top:15px;transform:translateX(6px);color:#d8e5f2;font-weight:700;white-space:nowrap}}.guide-grid-line{{position:absolute;top:0;bottom:0;width:1px;background:#26384c}}
.guide-program{{position:absolute;top:7px;height:62px;border:1px solid #36516c;border-radius:8px;background:#1b3147;padding:7px 9px;overflow:hidden;min-width:12px}}.guide-program strong{{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px}}.guide-program small{{display:block;color:#b7c7d7;margin-top:5px;white-space:nowrap;font-size:11px}}.guide-filler{{background:var(--filler);border-style:dashed}}.guide-commercial{{background:var(--commercial)}}.guide-current-program{{background:var(--current);outline:2px solid #5fb3ff;outline-offset:-2px}}
.guide-current-marker{{position:absolute;top:52px;bottom:0;width:2px;background:#ff5b5b;z-index:9;pointer-events:none}}.guide-current-marker:before{{content:"NOW";position:absolute;top:-20px;left:-17px;font-size:10px;background:#ff5b5b;color:white;padding:2px 5px;border-radius:4px}}
.guide-empty{{padding:32px;color:var(--muted)}}@media(max-width:720px){{.guide-time-row,.guide-row{{grid-template-columns:230px max-content}}.guide-channel-head,.guide-channel{{width:230px}}}}
</style></head><body>
<div class="guide-head"><div class="guide-title"><div><h1>Personal Cable TV Guide</h1><a href="/">← Back to Setup</a></div><div class="guide-nav"><a href="/guide?category={selected}&start={urllib.parse.quote(prev_start)}">← Earlier</a><a href="/guide?category={selected}">Now</a><a href="/guide?category={selected}&start={urllib.parse.quote(next_start)}">Later →</a></div></div><div class="guide-categories">{categories}</div></div>
<div class="guide-shell"><div class="guide-time-row"><div class="guide-channel-head"><b>{html.escape(category)}</b><br><small>{len(model["channels"])} channels</small></div><div class="guide-time-track" style="width:{timeline_width}px">{grid_lines}{slots}</div></div><div id="guide-current-marker" class="guide-current-marker" style="left:calc(280px + {marker_left:.1f}px)" data-window-start="{html.escape(model["start_utc"])}" data-ppm="{pixels_per_minute}" data-window-minutes="{model["window_minutes"]}"></div>{"".join(rows)}</div>
<script>(function(){{const m=document.getElementById('guide-current-marker');if(!m)return;function tick(){{const start=Date.parse(m.dataset.windowStart),ppm=parseFloat(m.dataset.ppm),limit=parseFloat(m.dataset.windowMinutes),mins=(Date.now()-start)/60000,clamped=Math.max(0,Math.min(limit,mins));m.style.left='calc(280px + '+(clamped*ppm)+'px)';}}tick();setInterval(tick,60000);}})();</script>
</body></html>"""

    def guide_xml(self, at: datetime | None = None) -> str:
        now = at or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        now = now.astimezone(timezone.utc)
        with self._guide_cache_lock:
            monotonic_now = time.monotonic()
            if self._guide_cache_xml is not None and self._guide_cache_expires_at > monotonic_now:
                return self._guide_cache_xml
            xml = build_xmltv(
                self.db,
                now - timedelta(hours=6),
                now + timedelta(days=7),
                self.tz_name,
                at=now,
            )
            self._guide_cache_xml = xml
            self._guide_cache_expires_at = monotonic_now + 300.0
            return xml

    def ensure_schedule_coverage(self, at: datetime | None = None) -> bool:
        now = at or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        now = now.astimezone(timezone.utc)
        required_end = now + timedelta(days=7)

        coverage_raw = (self.db.get_setting("schedule_coverage_end_utc", "") or "").strip()
        coverage_end = None
        if coverage_raw:
            try:
                coverage_end = datetime.fromisoformat(coverage_raw)
                if coverage_end.tzinfo is None:
                    coverage_end = coverage_end.replace(tzinfo=timezone.utc)
                coverage_end = coverage_end.astimezone(timezone.utc)
            except ValueError:
                coverage_end = None

        if coverage_end is None:
            max_end_raw = self.db.schedule_max_end_utc()
            if max_end_raw:
                try:
                    coverage_end = datetime.fromisoformat(max_end_raw)
                    if coverage_end.tzinfo is None:
                        coverage_end = coverage_end.replace(tzinfo=timezone.utc)
                    coverage_end = coverage_end.astimezone(timezone.utc)
                    self.db.set_setting("schedule_coverage_end_utc", coverage_end.isoformat())
                except ValueError:
                    coverage_end = None

        if coverage_end is not None and coverage_end >= required_end:
            return False
        self.rebuild_schedules()
        return True

    def create_channel(self, form: dict[str, str]) -> int:
        number = int(form.get("number") or 0)
        name = (form.get("name") or "").strip()
        preset = form.get("preset") or "all_movies"
        commercials = str(form.get("commercials_enabled", "0")).lower() in {"1", "true", "on", "yes"}
        if number <= 0:
            raise ValueError("Channel number must be greater than zero")
        if not name:
            raise ValueError("Channel name is required")
        if preset not in PRESETS:
            raise ValueError("Unknown channel preset")
        seasonal, seasonal_start, seasonal_end = self._seasonal_values(form)
        channel_id = self.db.create_channel(number, name, preset, commercials)
        if seasonal:
            self.db.update_channel(channel_id, number, name, preset, commercials, True, seasonal_start, seasonal_end)
        self.rebuild_schedules()
        return channel_id

    @staticmethod
    def _validate_mmdd(value: str, label: str) -> str:
        value = value.strip()
        try:
            datetime.strptime(f"2000-{value}", "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError(f"{label} must use MM-DD, for example 12-01") from exc
        return value

    def _seasonal_values(self, form: dict[str, str | list[str]]) -> tuple[bool, str | None, str | None]:
        seasonal = str(form.get("seasonal_enabled", "0")).lower() in {"1", "true", "on", "yes"}
        if not seasonal:
            return False, None, None
        start = self._validate_mmdd(str(form.get("seasonal_start") or ""), "Seasonal start")
        end = self._validate_mmdd(str(form.get("seasonal_end") or ""), "Seasonal end")
        return True, start, end

    def edit_channel(self, channel_id: int, form: dict[str, str | list[str]]) -> None:
        if not self.db.get_channel(channel_id):
            raise ValueError("Channel not found")
        number = int(form.get("number") or 0)
        name = str(form.get("name") or "").strip()
        preset = str(form.get("preset") or "all_movies")
        commercials = str(form.get("commercials_enabled", "0")).lower() in {"1", "true", "on", "yes"}
        if number <= 0:
            raise ValueError("Channel number must be greater than zero")
        if not name:
            raise ValueError("Channel name is required")
        if preset not in PRESETS:
            raise ValueError("Unknown channel preset")
        seasonal, start, end = self._seasonal_values(form)
        self.db.update_channel(channel_id, number, name, preset, commercials, seasonal, start, end)
        self.rebuild_schedules()

    def delete_channel(self, channel_id: int, form: dict[str, str | list[str]]) -> None:
        if str(form.get("confirm") or "").strip().lower() != "delete":
            raise ValueError("Channel deletion was not confirmed")
        if not self.db.get_channel(channel_id):
            raise ValueError("Channel not found")
        self.db.delete_channel(channel_id)
        self.rebuild_schedules()

    def add_rule(self, form: dict[str, str | list[str]]) -> int:
        channel_id = int(form.get("channel_id") or 0)
        label = str(form.get("label") or "Programming Rule").strip()
        preset = str(form.get("preset") or "all_movies")
        if preset not in PRESETS:
            raise ValueError("Unknown rule preset")
        raw_days = form.get("days", [])
        if isinstance(raw_days, str):
            raw_days = [raw_days] if raw_days else []
        days = [int(d) for d in raw_days]
        start_time = str(form.get("start_time") or "00:00")
        end_time = str(form.get("end_time") or "23:59")
        date_start = str(form.get("date_start") or "") or None
        date_end = str(form.get("date_end") or "") or None
        priority = int(form.get("priority") or 10)
        rule_id = self.db.add_rule(channel_id, label, preset, days, start_time, end_time, date_start, date_end, priority)
        self.rebuild_schedules()
        return rule_id

    def base_url_for_request(self, headers, server_address) -> str:
        if self.public_base_url:
            return self.public_base_url
        host = headers.get("Host")
        if host:
            return f"http://{host}"
        return f"http://{server_address[0]}:{server_address[1]}"

    def set_full_library_ignored(self, library_id: str, ignored: bool) -> None:
        self.db.set_full_library_ignored(library_id, ignored)

    def set_full_library_guide_category(self, library_id: str, form: dict[str, str | list[str]]) -> None:
        category = str(form.get("guide_category") or "").strip()
        self.db.set_full_library_guide_category(library_id, category)
        self.invalidate_guide_cache()

    def full_library_state(self) -> dict:
        libraries = self.db.list_full_libraries(include_ignored=False)
        ignored_libraries = self.db.list_full_libraries(include_ignored=True)
        active_ids = {str(library["id"]) for library in libraries}
        all_media = self.db.list_media(source_mode="full")
        media = [m for m in all_media if str(m.get("jellyfin_library_id") or "") in active_ids]
        stream_ready = sum(1 for item in media if item.get("playable"))
        per_library = []
        for library in libraries:
            rows = [m for m in media if m.get("jellyfin_library_id") == library["id"]]
            row_ready = sum(1 for m in rows if m.get("playable"))
            per_library.append({
                **library,
                "item_count": len(rows),
                "stream_ready_count": row_ready,
                "stream_warning_count": len(rows) - row_ready,
            })
        return {
            "libraries": per_library,
            "ignored_libraries": ignored_libraries,
            "library_count": len(libraries),
            "item_count": len(media),
            "stream_ready_count": stream_ready,
            "stream_warning_count": len(media) - stream_ready,
            "sync": self.db.get_full_sync_state(),
            "suggestions": self.suggestions.generate(),
        }

    def _full_library_sections_html(self) -> dict[str, str]:
        info = self.full_library_state()
        full_url = html.escape(self.db.get_setting("full_jellyfin_url", "") or "", quote=True)
        key_status = "API key saved" if self.db.get_setting("full_jellyfin_api_key", "") else "No API key saved"
        sync = info["sync"]
        last_sync = html.escape(sync.get("last_success_at") or "Never")
        next_sync = html.escape(sync.get("next_sync_at") or "Not scheduled")
        library_rows = []
        for library in info["libraries"]:
            error = library.get("last_error")
            error_text = f" · Sync warning: {html.escape(str(error))}" if error else ""
            library_id = html.escape(str(library["id"]), quote=True)
            current_category = str(library.get("guide_category") or "TV Shows")
            category_options = "".join(
                f'<option value="{html.escape(category, quote=True)}"{" selected" if category == current_category else ""}>{html.escape(category)}</option>'
                for category in PERSISTED_SOURCE_CATEGORIES
            )
            library_rows.append(
                f'<div class="channelbox"><div class="library-row"><span><b>{html.escape(library["name"])}</b>'
                f'<small>{library["item_count"]} items · {library["stream_ready_count"]} stream-ready · '
                f'{library["stream_warning_count"]} stream warnings{error_text}</small></span>'
                f'<div class="library-actions"><form method="post" action="/api/full-library/libraries/{library_id}/category" class="category-form">'
                f'<select name="guide_category" aria-label="Guide category for {html.escape(str(library["name"]), quote=True)}">{category_options}</select>'
                f'<button class="secondary compact" type="submit">Update Category</button></form>'
                f'<form method="post" action="/api/full-library/libraries/{library_id}/ignore">'
                f'<button class="secondary compact" type="submit">Ignore</button></form></div></div></div>'
            )
        libraries_html = "".join(library_rows) or '<div class="empty">Run Sync Now to discover Jellyfin libraries. Collections will be ignored.</div>'

        suggestion_groups: dict[str, dict] = {}
        for suggestion in info["suggestions"]:
            library_id_raw = str(suggestion["source_library_id"])
            group = suggestion_groups.setdefault(library_id_raw, {"name": str(suggestion["source_library_name"]), "rows": []})
            season = " · Seasonal" if suggestion.get("seasonal") else ""
            filter_json = html.escape(json.dumps(suggestion.get("filter") or {}, sort_keys=True), quote=True)
            library_id = html.escape(library_id_raw, quote=True)
            group["rows"].append(
                f'<div class="channel"><span><strong>{html.escape(suggestion["name"])}</strong>'
                f'<small>{suggestion["matching_count"]} matching items{season}</small></span>'
                f'<form method="post" action="/api/full-library/suggestions/create">'
                f'<input type="hidden" name="source_library_id" value="{library_id}">'
                f'<input type="hidden" name="filter_json" value="{filter_json}">'
                f'<button class="secondary">Create Channel</button></form></div>'
            )
        group_html = []
        for group in sorted(suggestion_groups.values(), key=lambda row: row["name"].casefold()):
            count = len(group["rows"])
            group_html.append(
                f'<details class="suggestion-group"><summary><strong>{html.escape(group["name"])}</strong>'
                f'<small>{count} channel suggestions</small></summary>' + "".join(group["rows"]) + '</details>'
            )
        suggestions_html = "".join(group_html) or '<div class="empty">No eligible suggestions yet. A suggestion needs at least 5 stream-ready matching items.</div>'

        ignored_rows = []
        for library in info["ignored_libraries"]:
            library_id = html.escape(str(library["id"]), quote=True)
            ignored_rows.append(
                f'<div class="library-row"><span><b>{html.escape(str(library["name"]))}</b>'
                f'<small>Ignored by Personal Cable TV · Jellyfin is unchanged</small></span>'
                f'<form method="post" action="/api/full-library/libraries/{library_id}/restore">'
                f'<button class="secondary compact" type="submit">Restore</button></form></div>'
            )
        ignored_html = "".join(ignored_rows)

        source_options = "".join(
            f'<option value="{html.escape(str(library["id"]), quote=True)}">{html.escape(str(library["name"]))}</option>'
            for library in info["libraries"]
        ) or '<option value="">Sync libraries first</option>'

        jellyfin_html = (
            '<div class="layout"><section class="card"><div class="section-heading"><h2>Full Library Mode</h2><a class="action-link" href="/guide">Open Guide</a></div>'
            '<p>Connect Jellyfin once. Personal Cable TV reads metadata and requests playback from Jellyfin; no real NAS media mounts are required.</p>'
            f'<p><b>{info["library_count"]} libraries connected · {info["item_count"]} items synced · '
            f'{info["stream_ready_count"]} stream-ready · {info["stream_warning_count"]} stream warnings</b></p>'
            f'<p>Last successful sync: {last_sync}<br>Next automatic sync: {next_sync}</p>'
            f'<form method="post" action="/api/full-library/settings"><input name="url" value="{full_url}" placeholder="http://YOUR-NAS-IP:8096" required>'
            f'<input name="api_key" type="password" placeholder="Leave blank to keep saved API key"><span class="safe">{key_status}</span>'
            '<button>Save Full Library Settings</button></form>'
            '<form method="post" action="/api/full-library/sync" style="margin-top:10px"><button class="secondary">Sync Now</button></form></section>'
            '<section class="card"><h2>Connection Notes</h2><p>The saved API key is never displayed back in the page. Full Library sync uses Jellyfin metadata and playback APIs only.</p>'
            '<button type="button" class="secondary section-link" data-section-target="help" data-help-target="help-api-key">How to get a Jellyfin API key</button></section></div>'
        )
        libraries_panel = (
            '<div class="layout single-wide"><section class="card"><div class="section-heading"><div><h2>Source Libraries</h2>'
            '<p>Assign each Jellyfin library to the Personal Cable TV guide category you want.</p></div>'
            '<button type="button" class="secondary compact section-link" data-section-target="help" data-help-target="help-libraries">Library Help</button></div>'
            '<div class="scrollbox">' + libraries_html + '</div>' +
            (('<details class="subdetails"><summary>Ignored Libraries</summary><div class="scrollbox compact-scroll">' + ignored_html + '</div></details>') if ignored_html else '') +
            '</section></div>'
        )
        channels_panel = (
            '<div class="layout"><section class="card"><h2>Channel Suggestions</h2><p>Each suggestion uses exactly one source library. Suggestions stay collapsed until you open a library.</p>'
            + suggestions_html +
            '<form method="post" action="/api/full-library/auto-create" style="margin-top:14px" onsubmit="return confirm(&quot;Create all currently eligible suggested channels?&quot;);">'
            '<button class="secondary">Automatic Create Channels</button></form><p>Seasonal automatic channels reserve 1-20. Regular automatic channels start at 100.</p></section>'
            '<section class="card"><h2>Manual Full Library Channel</h2><p>Choose exactly one source library. Filters are optional and may match fewer than 5 items.</p>'
            '<form method="post" action="/api/full-library/channels"><div class="row"><input name="number" type="number" min="1" placeholder="Channel #" required><input name="name" placeholder="Channel name" required></div>'
            f'<select name="source_library_id" required>{source_options}</select>'
            '<div class="row"><input name="genre" placeholder="Genre (optional)"><input name="tag" placeholder="Tag (optional)"></div>'
            '<div class="row"><input name="year_min" type="number" placeholder="Year from"><input name="year_max" type="number" placeholder="Year to"></div>'
            '<input name="title_keywords" placeholder="Title keywords, comma separated (optional)"><input name="item_ids" placeholder="Specific Jellyfin item IDs, comma separated (optional)">'
            '<label><input style="width:auto" type="checkbox" name="commercials_enabled" value="1"> Insert commercials between programs</label>'
            '<button>Create Manual Channel</button></form></section></div>'
        )
        return {"jellyfin": jellyfin_html, "libraries": libraries_panel, "channels": channels_panel}

    def run_due_full_sync_once(self, now: datetime | None = None) -> str:
        url = (self.db.get_setting("full_jellyfin_url", "") or "").strip()
        api_key = (self.db.get_setting("full_jellyfin_api_key", "") or "").strip()
        if not url or not api_key:
            return "not_configured"
        if not self.full_sync.is_due(now):
            return "not_due"
        self.sync_full_library()
        return "synced"

    def state(self) -> dict:
        media = self.db.list_media()
        return {
            "version": __version__,
            "media_count": len(media),
            "channel_count": len(self.db.list_channels()),
            "commercial_count": sum(1 for m in media if m["kind"] == "commercial"),
            "media_root": str(self.media_root),
            "safety_mode": "development override" if self.allow_writable_media else "read-only required",
            "stream_mode": self.stream_mode,
        }

    def _preset_options(self, selected: str | None = None) -> str:
        return "".join(
            f'<option value="{html.escape(key)}"{" selected" if key == selected else ""}>{html.escape(label)}</option>'
            for key, label in PRESETS.items()
        )

    @staticmethod
    def _full_filter_summary(filter_spec: dict | None) -> str:
        spec = filter_spec or {}
        parts: list[str] = []
        if spec.get("genre"):
            parts.append(f"Genre: {spec['genre']}")
        if spec.get("tag"):
            parts.append(f"Tag: {spec['tag']}")
        if spec.get("tags_any"):
            parts.append("Tags: " + ", ".join(str(x) for x in spec["tags_any"]))
        year_min, year_max = spec.get("year_min"), spec.get("year_max")
        if year_min is not None and year_max is not None:
            parts.append(f"Years: {year_min}-{year_max}")
        elif year_min is not None:
            parts.append(f"Year: {year_min}+")
        elif year_max is not None:
            parts.append(f"Year: through {year_max}")
        if spec.get("title_keywords"):
            parts.append("Title: " + ", ".join(str(x) for x in spec["title_keywords"]))
        if spec.get("item_ids"):
            parts.append(f"Items: {len(spec['item_ids'])} selected")
        return " · ".join(parts) or "All items in source"

    def _channel_card_html(self, channel: dict, now: datetime) -> str:
        seasonal = bool(channel.get("seasonal_enabled"))
        active = is_channel_active(channel, now, self.tz_name)
        status = "Active now" if active else "Hidden until seasonal window"
        season_text = ""
        if seasonal:
            season_text = f' · Yearly {html.escape(channel.get("seasonal_start") or "")} to {html.escape(channel.get("seasonal_end") or "")}'
        checked_commercials = " checked" if channel.get("commercials_enabled") else ""
        checked_seasonal = " checked" if seasonal else ""
        safe_name = html.escape(channel["name"], quote=True)
        confirm_name = html.escape(channel["name"], quote=True).replace("'", "&#39;")
        if channel.get("source_mode") == "full":
            library = self.db.get_full_library(str(channel.get("source_library_id") or ""))
            library_name = str((library or {}).get("name") or channel.get("source_library_id") or "Unknown source")
            detail_text = f"Full Library · {library_name} · {self._full_filter_summary(channel.get('filter'))}"
            preset_control = '<input type="hidden" name="preset" value="all">'
        else:
            detail_text = PRESETS.get(channel["default_preset"], channel["default_preset"])
            preset_control = f'<select name="preset">{self._preset_options(channel["default_preset"])}</select>'
        return (
            f'<details class="channelbox"><summary><span class="num">{channel["number"]}</span>'
            f'<span><strong title="{safe_name}">{html.escape(channel["name"])}</strong>'
            f'<small>{html.escape(detail_text)}{season_text} · {status}</small></span></summary>'
            f'<form method="post" action="/api/channels/{channel["id"]}/edit" class="channel-edit">'
            f'<div class="row"><input name="number" type="number" min="1" value="{channel["number"]}" required>'
            f'<input name="name" value="{safe_name}" required></div>'
            f'{preset_control}'
            f'<label><input style="width:auto" type="checkbox" name="commercials_enabled" value="1"{checked_commercials}> Insert commercials between programs</label>'
            f'<label><input style="width:auto" type="checkbox" name="seasonal_enabled" value="1"{checked_seasonal}> Seasonal channel — Repeat every year</label>'
            f'<div class="row"><input name="seasonal_start" placeholder="Start MM-DD (12-01)" value="{html.escape(channel.get("seasonal_start") or "", quote=True)}">'
            f'<input name="seasonal_end" placeholder="End MM-DD (12-26)" value="{html.escape(channel.get("seasonal_end") or "", quote=True)}"></div>'
            f'<button>Save Channel</button></form>'
            f'<form method="post" action="/api/channels/{channel["id"]}/delete" onsubmit="return confirm(\'Delete channel {channel["number"]} {confirm_name}? This does not delete media files.\');">'
            f'<input type="hidden" name="confirm" value="delete"><button class="danger">Delete Channel</button></form></details>'
        )

    def dashboard_html(self, base_url: str) -> str:
        state = self.state()
        channels = sorted(self.db.list_channels(), key=lambda channel: int(channel["number"]))
        now = datetime.now(timezone.utc)
        now_rows = []
        for ch in channels:
            if not is_channel_active(ch, now, self.tz_name):
                continue
            current = self.scheduler.current_program(ch["id"], now)
            next_program = None
            for row in self.db.list_schedule(ch["id"], now, now + timedelta(hours=24)):
                row_start = datetime.fromisoformat(str(row["start_utc"]))
                if row_start.tzinfo is None:
                    row_start = row_start.replace(tzinfo=timezone.utc)
                if row_start <= now:
                    continue
                row_type = str(row.get("row_type") or ("commercial" if row.get("is_commercial") else "content"))
                if row_type == "content":
                    next_program = row
                    break
            now_rows.append((ch, current, next_program))

        preset_options = self._preset_options()
        channel_options = "".join(
            f'<option value="{c["id"]}">{c["number"]} — {html.escape(c["name"])}</option>'
            for c in channels if c.get("source_mode") == "test"
        )
        channel_cards = "".join(self._channel_card_html(c, now) for c in channels) or '<div class="empty">No channels yet. Scan media, then create your first channel.</div>'
        visible_now_rows = now_rows[:8]
        now_cards = "".join(
            f'<div class="nowrow"><span class="now-num">{c["number"]}</span><b class="now-channel">{html.escape(c["name"])}</b>'
            f'<span class="now-current">{html.escape(cur["title"]) if cur else "No scheduled program"}</span>'
            f'<span class="now-next">{("Up Next: " + html.escape(nxt["title"])) if nxt else "No upcoming program"}</span></div>'
            for c, cur, nxt in visible_now_rows
        ) or '<div class="empty">Create a channel to see Now Playing.</div>'
        now_summary = (
            f'<small class="list-note">Showing {len(visible_now_rows)} of {len(now_rows)} active channels</small>'
            if now_rows else ''
        )
        full_sections = self._full_library_sections_html()

        nav_items = (
            ("dashboard", "Dashboard"),
            ("channels", "Channels"),
            ("programming", "Programming"),
            ("jellyfin", "Jellyfin"),
            ("libraries", "Libraries"),
            ("settings", "Settings"),
            ("help", "Help & Support"),
        )
        nav_html = "".join(
            f'<button type="button" class="nav-button{" active" if key == "dashboard" else ""}" data-section-target="{key}">{label}</button>'
            for key, label in nav_items
        )

        dashboard_panel = f'''
<section class="app-section active" id="section-dashboard" data-section="dashboard">
  <div class="grid">
    <div class="stat"><b>{state['media_count']}</b><span>Media items</span></div>
    <div class="stat"><b>{state['channel_count']}</b><span>Channels</span></div>
    <div class="stat"><b>{state['commercial_count']}</b><span>Commercials</span></div>
    <div class="stat"><b>{html.escape(state['stream_mode'])}</b><span>FFmpeg mode</span></div>
  </div>
  <div class="layout dashboard-layout">
    <section class="card"><div class="section-heading"><h2>Now Playing</h2><button type="button" class="secondary compact section-link view-all" data-section-target="channels">View All →</button></div>
      <div class="now-head"><span>#</span><span>Channel</span><span>Now Playing</span><span>Up Next</span></div>
      <div class="now-list">{now_cards}</div>{now_summary}
    </section>
    <section class="card"><h2>Quick Actions</h2><div class="quick-actions">
      <button type="button" class="secondary section-link" data-section-target="channels">Create / Manage Channels</button>
      <form method="post" action="/api/rebuild"><button class="secondary">Rebuild 7-Day Guide</button></form>
      <form method="post" action="/api/full-library/sync"><button class="secondary">Sync Jellyfin Now</button></form>
      <a class="action-link secondary-action" href="/guide">Open Personal Cable TV Guide</a>
    </div></section>
  </div>
</section>'''

        channels_panel = f'''
<section class="app-section" id="section-channels" data-section="channels">
  <div class="section-title"><div><h2>Channels</h2><p>Create, edit, organize, or remove Personal Cable TV channels. Removing a channel never deletes its media.</p></div><a class="action-link" href="/guide">Open Guide</a></div>
  <div class="layout">
    <section class="card"><h2>Scan Test Media</h2><p>Test Mode scans only <code>{html.escape(str(self.media_root))}</code>. The CasaOS package mounts this location read-only.</p><form method="post" action="/api/scan"><button>Scan Test Media</button></form></section>
    <section class="card"><h2>Create Test Channel</h2><form method="post" action="/api/channels"><div class="row"><input name="number" type="number" min="1" placeholder="Channel # (e.g. 13)" required><input name="name" placeholder="Horror Central" required></div><select name="preset">{preset_options}</select><label><input style="width:auto" type="checkbox" name="commercials_enabled" value="1"> Insert commercials between programs</label><label><input style="width:auto" type="checkbox" name="seasonal_enabled" value="1"> Seasonal channel — Repeat every year</label><div class="row"><input name="seasonal_start" placeholder="Start MM-DD (12-01)"><input name="seasonal_end" placeholder="End MM-DD (12-26)"></div><button>Create Channel</button></form></section>
  </div>
  <section class="card top-gap"><div class="section-heading"><div><h2>All Channels</h2><p>Sorted by channel number. Open a row to edit it.</p></div><span class="count-pill">{len(channels)} channels</span></div><div class="scrollbox channel-scroll">{channel_cards}</div></section>
  {full_sections['channels']}
</section>'''

        programming_panel = f'''
<section class="app-section" id="section-programming" data-section="programming">
  <div class="section-title"><div><h2>Programming</h2><p>Override a Test Mode channel's default programming for selected times, days, or dates.</p></div></div>
  <div class="layout single-wide"><section class="card"><h2>Programming Rule</h2><p>Example: Family by day, Horror from 6 PM to midnight.</p><form method="post" action="/api/rules"><select name="channel_id" required><option value="">Choose channel…</option>{channel_options}</select><div class="row"><input name="label" placeholder="Night Horror"><select name="preset">{preset_options}</select></div><div class="row"><input name="start_time" type="time" value="18:00"><input name="end_time" type="time" value="23:59"></div><div class="daygrid">{''.join(f'<label><input type="checkbox" name="days" value="{i}">{d}</label>' for i,d in enumerate(['Mon','Tue','Wed','Thu','Fri','Sat','Sun']))}</div><div class="row"><input name="date_start" type="date"><input name="date_end" type="date"></div><input name="priority" type="number" value="50"><button>Add Programming Rule</button></form></section></div>
</section>'''

        jellyfin_panel = f'''
<section class="app-section" id="section-jellyfin" data-section="jellyfin">
  <div class="section-title"><div><h2>Jellyfin</h2><p>Connect Personal Cable TV to Jellyfin Live TV and Full Library Mode.</p></div><button type="button" class="secondary compact section-link" data-section-target="help" data-help-target="help-jellyfin-live-tv">Setup Help</button></div>
  <div class="layout"><section class="card links"><h2>Jellyfin Live TV URLs</h2><p>Paste these into Jellyfin's M3U tuner and XMLTV guide provider.</p><p class="warn">Channel lineup changes update these feeds immediately. Jellyfin may cache new or removed channels; use Refresh Guide Data, and if a row stays blank, restart Jellyfin.</p><b>M3U Tuner</b><code>{html.escape(base_url)}/iptv/channels.m3u</code><b>XMLTV Guide</b><code>{html.escape(base_url)}/iptv/guide.xml</code><form method="post" action="/api/rebuild"><button class="secondary">Rebuild 7-Day Guide</button></form></section>
  <section class="card"><h2>Legacy Metadata Import</h2><p>This performs GET requests only. It does not install a plugin or modify Jellyfin media.</p><form method="post" action="/api/jellyfin/import"><input name="url" placeholder="http://YOUR-NAS-IP:8096"><input name="api_key" type="password" placeholder="Jellyfin API key"><button class="secondary">Import Metadata</button></form></section></div>
  {full_sections['jellyfin']}
</section>'''

        libraries_panel = f'''
<section class="app-section" id="section-libraries" data-section="libraries">
  <div class="section-title"><div><h2>Libraries</h2><p>Manage how synced Jellyfin source libraries are categorized inside Personal Cable TV.</p></div></div>
  {full_sections['libraries']}
</section>'''

        settings_panel = '''
<section class="app-section" id="section-settings" data-section="settings">
  <div class="section-title"><div><h2>Settings</h2><p>Optional integrations and interface information.</p></div></div>
  <div class="layout">
    <section class="card"><h2>Personal Cable TV Jellyfin Companion</h2><p><b>Personal Cable TV works with Jellyfin Live TV without the Companion.</b> If you want Jellyfin Live TV to use the enhanced Personal Cable TV interface shown by this project, install the optional <b>Personal Cable TV Jellyfin Companion</b>. It adds the custom On Now and cable-style Guide experience without changing your Personal Cable TV media safety rules.</p><button type="button" class="secondary section-link" data-section-target="help" data-help-target="help-companion">Companion Help & Device Support</button></section>
    <section class="card"><h2>Device Support</h2><div class="support-list"><div><b>Web Browser</b><span class="status supported">Supported</span></div><div><b>LG webOS TV</b><span class="status supported">Supported</span></div><div><b>Roku TV</b><span class="status coming">Coming Soon</span></div><div><b>Other Jellyfin clients</b><span>Standard Jellyfin interface</span></div></div><p class="muted-note">A Roku TV version of the enhanced experience is in development and is not enabled yet.</p></section>
  </div>
</section>'''

        help_panel = f'''
<section class="app-section" id="section-help" data-section="help">
  <div class="section-title"><div><h2>Help & Support</h2><p>Open only the topic you need. Your saved Jellyfin API key is never shown here.</p></div><span class="count-pill">v{__version__}</span></div>
  <div class="help-stack">
    <details class="help-card"><summary>Getting Started</summary><div><p>Personal Cable TV creates scheduled linear channels from your own library and exposes them to Jellyfin through M3U and XMLTV feeds. Tuning a channel joins the current scheduled position like real cable TV.</p><p>Start with Jellyfin setup, sync your libraries, review categories, create channels, rebuild the guide, then refresh guide data in Jellyfin.</p></div></details>
    <details class="help-card" id="help-api-key"><summary>Jellyfin API Key</summary><div><p>In Jellyfin, open <b>Dashboard → Advanced → API Keys</b>, create a new key for Personal Cable TV, copy it once, then paste it into the Jellyfin / Full Library settings in Personal Cable TV.</p><p><b>Your API key is a credential.</b> Do not post it in screenshots or share it with other people. If a key is exposed, revoke it in Jellyfin and create a replacement.</p><p>Personal Cable TV stores the key in its own application data and masks it in the interface after it is saved.</p></div></details>
    <details class="help-card" id="help-jellyfin-live-tv"><summary>M3U & XMLTV Setup in Jellyfin</summary><div><p>Add <code>{html.escape(base_url)}/iptv/channels.m3u</code> as an M3U tuner and <code>{html.escape(base_url)}/iptv/guide.xml</code> as the XMLTV guide provider in Jellyfin Live TV settings.</p><p>After channel or schedule changes, use <b>Refresh Guide Data</b> in Jellyfin. If a cached row remains blank after a refresh, restart Jellyfin.</p></div></details>
    <details class="help-card safety-help" id="media-safety"><summary>Media Safety — What Personal Cable TV Can and Cannot Change</summary><div><p><b>Personal Cable TV does not delete, rename, move, replace, overwrite, or modify your media files.</b> Your movies, TV shows, cartoons, anime, and other library files remain untouched.</p><p>The CasaOS package gives Test Mode read-only access to <code>/media</code>. Full Library Mode does not mount your real NAS libraries into Personal Cable TV; it reads metadata and requests playback through Jellyfin.</p><p>Ignoring a library, deleting a channel, changing a category, or rebuilding a guide only changes Personal Cable TV application data. It does not remove media from Jellyfin or your NAS.</p></div></details>
    <details class="help-card" id="help-libraries"><summary>Libraries & Categories</summary><div><p><b>Sync Now</b> discovers supported Jellyfin libraries and media metadata. Jellyfin virtual Collections are ignored. Each channel uses exactly one source library.</p><p>Use <b>Update Category</b> to control where a library appears in the Personal Cable TV Guide. <b>Ignore</b> hides the library only from Personal Cable TV; <b>Restore</b> brings it back.</p><p>Stream-ready counts show items that can be requested for playback. Warnings identify items that need review without deleting or changing those files.</p></div></details>
    <details class="help-card"><summary>Channels & Programming</summary><div><p>Automatic channel suggestions require at least five eligible stream-ready items. Seasonal automatic channels reserve 1-20; regular automatic channels start at 100. Manual channels can use fewer items.</p><p>Real programs are aligned to :00 or :30 where possible. Short <b>Up Next</b> filler bridges the gap without cutting a movie or episode. Programming Rules can override Test Mode channel presets for selected schedules.</p></div></details>
    <details class="help-card" id="help-companion"><summary>Enhanced Jellyfin Guide / Companion</summary><div><p>The <b>Personal Cable TV Jellyfin Companion</b> is an optional Jellyfin plugin. Personal Cable TV itself still supplies channels, schedules, M3U/XMLTV feeds, and playback without it.</p><p><b>If you want Jellyfin Live TV to use the enhanced Personal Cable TV interface</b> with On Now, the cable-style Guide, category navigation, and TV-friendly controls, install the Companion for the supported Jellyfin version.</p><p><b>Web Browser:</b> Supported. <b>LG webOS TV:</b> Supported through the Companion. <b>Roku TV:</b> Coming Soon — a Roku version is in development. <b>Other Jellyfin clients:</b> Standard Jellyfin interface unless separately supported.</p></div></details>
    <details class="help-card"><summary>Troubleshooting</summary><div><p><b>Missing channels:</b> confirm the channel is enabled/active, rebuild the 7-day guide, then refresh Jellyfin Guide Data.</p><p><b>Blank guide row:</b> refresh guide data; if Jellyfin still shows a stale row, restart Jellyfin.</p><p><b>Sync problem:</b> confirm the Jellyfin server address and API key, then run Sync Now. Do not expose the API key when sharing screenshots.</p><p><b>Playback problem:</b> note the channel number, title, approximate time, and whether the same item plays directly in Jellyfin.</p></div></details>
    <details class="help-card"><summary>About & Version</summary><div><p><b>Personal Cable TV v{__version__}</b><br>Mode: {html.escape(state['stream_mode'])}<br>Media safety: {html.escape(state['safety_mode'])}</p><p>Personal Cable TV writes only to its application data directory and preserves the existing read-only media safety rules.</p></div></details>
  </div>
</section>'''

        return f'''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Personal Cable TV</title><style>
:root{{--bg:#0b0f16;--panel:#121923;--panel2:#182231;--text:#eef2f3;--muted:#a4b0bc;--accent:#4a90e2;--good:#58c998;--warn:#d7ad5f;--line:#293847;--action:#242c35;--action-hover:#303b47;--action-pressed:#3a4653;--action-secondary:#202832;--danger:#6b3f45}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;background:linear-gradient(135deg,#080c12,#101927);color:var(--text)}}
header{{padding:22px 30px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:18px;position:sticky;top:0;background:#0b0f16f2;backdrop-filter:blur(12px);z-index:20}}h1{{margin:0;font-size:24px}}header small{{color:var(--muted)}}
.safe-badge{{width:auto;background:#153329;color:#79ddb2;border:1px solid #285745;padding:9px 12px;border-radius:999px;font-weight:700;white-space:nowrap}}
.app-nav-wrap{{position:sticky;top:89px;z-index:18;background:#0b0f16ee;border-bottom:1px solid var(--line);padding:10px 0}}.app-nav{{max-width:1320px;margin:auto;display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:7px;padding:2px 28px}}.nav-button{{width:100%;min-width:0;background:#171e26;border:1px solid #313d49;color:#cbd3da;box-shadow:none}}.nav-button.active{{background:#203a55;border-color:var(--accent);color:#fff;box-shadow:inset 0 -2px 0 var(--accent)}}.nav-button:hover{{background:#27323d;border-color:#43515f}}
main{{max-width:1320px;margin:auto;padding:20px 28px 30px}}.app-section{{display:none}}.app-section.active{{display:block}}.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}}.stat,.card,.help-card{{background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:0 12px 30px #0002}}.stat{{padding:17px}}.stat b{{display:block;font-size:25px}}.stat span{{color:var(--muted);font-size:13px}}
.layout{{display:grid;grid-template-columns:1.1fr .9fr;gap:16px;margin-top:16px}}.layout.single-wide{{grid-template-columns:1fr}}.dashboard-layout{{align-items:start}}.card{{padding:18px}}.top-gap{{margin-top:16px}}h2{{margin:0 0 12px;font-size:18px}}h3{{font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-top:18px}}p{{color:var(--muted);line-height:1.5}}.section-title,.section-heading{{display:flex;align-items:center;justify-content:space-between;gap:14px}}.section-title{{margin-bottom:4px}}.section-title p,.section-heading p{{margin:4px 0 0}}.count-pill{{background:#1d2b35;border:1px solid #334756;color:#cbd4da;border-radius:999px;padding:7px 10px;font-size:12px;white-space:nowrap}}
form{{display:grid;gap:9px}}input,select,button{{width:100%;padding:10px 12px;border-radius:9px;border:1px solid #344858;background:#0e1520;color:var(--text)}}button,.action-link{{background:var(--action);border:1px solid #3b4652;color:#eef2f6;font-weight:700;cursor:pointer;transition:background .14s ease,border-color .14s ease,transform .12s ease,filter .14s ease,box-shadow .14s ease}}button:hover,.action-link:hover{{background:var(--action-hover);border-color:#536171}}button:active,.action-link:active{{background:var(--action-pressed);border-color:var(--accent);transform:translateY(1px) scale(.99)}}button:focus-visible,.action-link:focus-visible,.nav-button:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}button.secondary{{background:var(--action-secondary);border-color:#374350;color:#dce3e9}}button.secondary:hover{{background:#2c3742;border-color:#4a5867}}button.danger{{background:var(--danger);border-color:#906060;color:#f5eded}}button.compact{{width:auto;padding:8px 11px}}.action-link{{display:inline-block;text-decoration:none;padding:9px 12px;border-radius:9px;white-space:nowrap;text-align:center}}.secondary-action{{background:var(--action-secondary);border-color:#374350;color:#dce3e9}}.text-link{{color:#7fb5ee;text-decoration:none;font-weight:700}}
@keyframes pctvPress{{0%{{background:var(--action)}}45%{{background:var(--action-pressed);transform:translateY(1px) scale(.985)}}100%{{transform:none}}}}.pctv-pressed{{animation:pctvPress 180ms ease-out}}.pctv-working{{background:#1d344b!important;border-color:var(--accent)!important;color:#fff!important;cursor:wait!important;opacity:1!important}}.pctv-done{{background:#254437!important;border-color:#4e8a6c!important;color:#eafff3!important}}button[aria-busy="true"]{{box-shadow:inset 3px 0 0 var(--accent)}}
.row{{display:grid;grid-template-columns:1fr 1fr;gap:9px}}.links code,.help-card code{{display:block;padding:9px;background:#091019;border:1px solid var(--line);border-radius:8px;margin:7px 0;word-break:break-all;color:#bdd2d0}}.channel{{display:flex;gap:12px;align-items:center;border-bottom:1px solid var(--line);padding:10px 0}}.channelbox{{border-bottom:1px solid var(--line);padding:9px 0}}.channelbox summary{{display:flex;gap:12px;align-items:center;cursor:pointer}}.channelbox summary span:last-child{{flex:1}}.channel-edit{{margin:11px 0;padding:11px;background:#0e1520;border-radius:9px}}.num{{font-size:21px;color:#89b7b2;width:46px}}.channel small,.library-row small{{display:block;color:var(--muted);margin-top:3px}}
.library-row{{display:flex;gap:12px;align-items:center;justify-content:space-between;padding:4px 0}}.library-row span{{flex:1}}.library-actions{{display:flex;align-items:center;gap:7px;flex-wrap:wrap}}.category-form{{display:flex;align-items:center;gap:7px;margin:0}}.category-form select{{min-width:145px;width:auto}}.suggestion-group{{border-bottom:1px solid var(--line);padding:7px 0}}.suggestion-group summary{{cursor:pointer;display:flex;justify-content:space-between;gap:12px;align-items:center;padding:7px 0}}.suggestion-group summary small{{color:var(--muted)}}.now-head,.nowrow{{display:grid;grid-template-columns:54px minmax(150px,1.05fr) minmax(180px,1.35fr) minmax(180px,1.2fr);gap:12px;align-items:center}}.now-head{{padding:0 0 8px;border-bottom:1px solid var(--line);color:#7f8d9a;font-size:11px;text-transform:uppercase;letter-spacing:.06em}}.now-list{{max-height:360px;overflow:auto;padding-right:4px}}.nowrow{{padding:10px 0;border-bottom:1px solid var(--line)}}.now-num{{font-weight:800;color:#8fc2f3}}.now-channel{{min-width:0}}.now-current,.now-next,.empty,.list-note{{color:var(--muted);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}.now-next{{color:#9fb7cf}}.list-note{{display:block;margin-top:9px}}.quick-actions{{display:grid;gap:10px}}.inline-actions{{display:flex;gap:8px}}.inline-actions button{{width:auto}}.scrollbox{{max-height:56vh;overflow:auto;padding-right:6px}}.compact-scroll{{max-height:240px}}.subdetails{{margin-top:14px;border-top:1px solid var(--line);padding-top:10px}}.subdetails summary{{cursor:pointer;font-weight:700}}.safe{{color:var(--good);font-weight:700}}.warn{{color:var(--warn)}}.muted-note{{font-size:13px}}.daygrid{{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;font-size:12px}}.daygrid label{{background:#0e1520;padding:8px;border-radius:8px;text-align:center}}.daygrid input{{width:auto}}
.support-list{{display:grid;gap:3px}}.support-list>div{{display:flex;justify-content:space-between;gap:14px;padding:10px 0;border-bottom:1px solid var(--line)}}.status{{font-weight:700}}.status.supported{{color:#73cea7}}.status.coming{{color:#d5b36e}}.help-stack{{display:grid;gap:10px}}.help-card{{padding:0;overflow:hidden}}.help-card summary{{cursor:pointer;padding:15px 17px;font-weight:800;background:#141e29}}.help-card>div{{padding:4px 17px 15px}}.help-card p{{margin:9px 0}}.safety-help{{border-color:#315b4b}}.safety-help summary{{color:#86d6b4;background:#10251e}}
@media(max-width:900px){{header{{position:relative}}.app-nav-wrap{{top:0}}.app-nav{{display:flex;overflow-x:auto;padding:2px 28px}}.nav-button{{width:auto;min-width:118px}}.grid{{grid-template-columns:1fr 1fr}}.layout{{grid-template-columns:1fr}}.scrollbox{{max-height:62vh}}}}@media(max-width:700px){{.now-head{{display:none}}.nowrow{{grid-template-columns:44px 1fr;gap:6px 10px}}.now-current,.now-next{{grid-column:2}}}}@media(max-width:560px){{main{{padding:14px}}header{{padding:17px;align-items:flex-start;flex-direction:column}}.app-nav-wrap{{padding:8px 0}}.app-nav{{padding:2px 14px}}.grid{{grid-template-columns:1fr 1fr}}.row{{grid-template-columns:1fr}}.library-row,.section-title,.section-heading{{align-items:flex-start;flex-direction:column}}.library-actions,.category-form{{width:100%}}.category-form select{{width:100%;min-width:0}}}}
</style></head><body>
<header><div><h1>Personal Cable TV <small>v{__version__}</small></h1><small>CasaOS → scheduled channels → Jellyfin Live TV</small></div><button type="button" class="safe-badge section-link" data-section-target="help" data-help-target="media-safety">Media safety: {html.escape(state['safety_mode'])}</button></header>
<div class="app-nav-wrap"><nav class="app-nav" aria-label="Personal Cable TV sections">{nav_html}</nav></div>
<main>{dashboard_panel}{channels_panel}{programming_panel}{jellyfin_panel}{libraries_panel}{settings_panel}{help_panel}</main>
<script>
(function(){{
  const storageKey='pctv-active-section';
  const valid=new Set(['dashboard','channels','programming','jellyfin','libraries','settings','help']);
  function showSection(name, remember=true){{
    if(!valid.has(name)) name='dashboard';
    document.querySelectorAll('.app-section').forEach(el=>el.classList.toggle('active',el.dataset.section===name));
    document.querySelectorAll('.nav-button').forEach(el=>el.classList.toggle('active',el.dataset.sectionTarget===name));
    if(remember){{try{{localStorage.setItem(storageKey,name);}}catch(_){{}}}}
    window.scrollTo({{top:0,behavior:'smooth'}});
  }}
  document.addEventListener('click',event=>{{
    const pressed=event.target.closest('button,.action-link');
    if(pressed){{pressed.classList.remove('pctv-pressed');void pressed.offsetWidth;pressed.classList.add('pctv-pressed');setTimeout(()=>pressed.classList.remove('pctv-pressed'),180);}}
    const target=event.target.closest('[data-section-target]');
    if(!target) return;
    event.preventDefault();
    showSection(target.dataset.sectionTarget);
    const helpId=target.dataset.helpTarget;
    if(helpId){{setTimeout(()=>{{const detail=document.getElementById(helpId);if(detail){{detail.open=true;detail.scrollIntoView({{behavior:'smooth',block:'start'}});}}}},40);}}
  }});
  document.addEventListener('submit',event=>{{
    const form=event.target.closest('form');
    if(!form) return;
    const button=form.querySelector('button[type="submit"],button:not([type])');
    if(!button) return;
    button.dataset.originalLabel=button.textContent.trim();
    button.textContent='Working…';
    button.classList.add('pctv-working');
    button.setAttribute('aria-busy','true');
    button.disabled=true;
  }});
  const donePath=new URLSearchParams(window.location.search).get('done');
  if(donePath){{
    document.querySelectorAll('form').forEach(form=>{{
      if(form.getAttribute('action')!==donePath) return;
      const button=form.querySelector('button[type="submit"],button:not([type])');
      if(!button) return;
      const original=button.textContent.trim();
      button.textContent='Done ✓';
      button.classList.add('pctv-done');
      setTimeout(()=>{{button.textContent=original;button.classList.remove('pctv-done');}},1400);
    }});
    if(window.history&&window.history.replaceState) window.history.replaceState({{}},'',window.location.pathname);
  }}
  let initial='dashboard';
  try{{const saved=localStorage.getItem(storageKey);if(valid.has(saved))initial=saved;}}catch(_){{}}
  showSection(initial,false);
}})();
</script></body></html>'''


class _Handler(BaseHTTPRequestHandler):
    app: CableTVApplication

    def log_message(self, format, *args):
        # Keep container logs concise.
        print(f"[http] {self.address_string()} - {format % args}")

    def _send(self, status: int, body: bytes, content_type: str = "text/plain; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: dict):
        self._send(status, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

    def _redirect_home(self, done_path: str | None = None):
        self.send_response(303)
        location = "/"
        if done_path:
            location = "/?done=" + urllib.parse.quote(done_path, safe="")
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _form(self) -> dict[str, str | list[str]]:
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length).decode("utf-8")
        parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
        result: dict[str, str | list[str]] = {}
        for key, values in parsed.items():
            result[key] = values if key == "days" else (values[-1] if values else "")
        return result

    def do_GET(self):
        parsed_request = urllib.parse.urlparse(self.path)
        path = parsed_request.path
        query = urllib.parse.parse_qs(parsed_request.query, keep_blank_values=True)
        base_url = self.app.base_url_for_request(self.headers, self.server.server_address)
        if path == "/":
            self._send(200, self.app.dashboard_html(base_url).encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == "/guide":
            self._send(200, self.app.guide_html(base_url, query).encode("utf-8"), "text/html; charset=utf-8")
            return
        if path == "/health":
            state = self.app.state(); state["status"] = "ok"
            self._json(200, state)
            return
        if path == "/api/state":
            self._json(200, self.app.state())
            return
        if path == "/iptv/channels.m3u":
            self._send(200, build_m3u(self.app.db, base_url, tz_name=self.app.tz_name).encode("utf-8"), "application/x-mpegURL; charset=utf-8")
            return
        if path == "/iptv/guide.xml":
            now = datetime.now(timezone.utc)
            xml = self.app.guide_xml(now)
            self._send(200, xml.encode("utf-8"), "application/xml; charset=utf-8")
            return
        if path.startswith("/iptv/channel/") and path.endswith(".ts"):
            try:
                channel_id = int(path.rsplit("/", 1)[1][:-3])
            except ValueError:
                self._json(400, {"error": "Invalid channel"}); return
            channel = self.app.db.get_channel(channel_id)
            if not channel:
                self._json(404, {"error": "Channel not found"}); return
            if not is_channel_active(channel, datetime.now(timezone.utc), self.app.tz_name):
                self._json(404, {"error": "Channel is outside its seasonal window"}); return
            try:
                stream = iter(self.app.stream_channel(channel_id))
                first_chunk = next(stream, None)
            except JellyfinPlaybackError as exc:
                self._json(503, {"error": str(exc)}); return
            if first_chunk is None:
                self._json(503, {"error": "No scheduled program is available"}); return
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(first_chunk)
                self.wfile.flush()
                for chunk in stream:
                    self.wfile.write(chunk)
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, JellyfinPlaybackError):
                pass
            return
        self._json(404, {"error": "Not found"})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        try:
            form = self._form()
            if path == "/api/scan":
                self.app.scan_media(); self._redirect_home(path); return
            if path == "/api/channels":
                self.app.create_channel(form); self._redirect_home(path); return
            if path.startswith("/api/channels/") and path.endswith("/edit"):
                channel_id = int(path.split("/")[3])
                self.app.edit_channel(channel_id, form); self._redirect_home(path); return
            if path.startswith("/api/channels/") and path.endswith("/delete"):
                channel_id = int(path.split("/")[3])
                self.app.delete_channel(channel_id, form); self._redirect_home(path); return
            if path == "/api/rules":
                self.app.add_rule(form); self._redirect_home(path); return
            if path == "/api/rebuild":
                self.app.rebuild_schedules(); self._redirect_home(path); return
            if path == "/api/full-library/settings":
                self.app.save_full_library_settings(form); self._redirect_home(path); return
            if path.startswith("/api/full-library/libraries/") and path.endswith("/category"):
                library_id = urllib.parse.unquote(path.split("/")[4])
                self.app.set_full_library_guide_category(library_id, form); self._redirect_home(path); return
            if path.startswith("/api/full-library/libraries/") and path.endswith("/ignore"):
                library_id = urllib.parse.unquote(path.split("/")[4])
                self.app.set_full_library_ignored(library_id, True); self._redirect_home(path); return
            if path.startswith("/api/full-library/libraries/") and path.endswith("/restore"):
                library_id = urllib.parse.unquote(path.split("/")[4])
                self.app.set_full_library_ignored(library_id, False); self._redirect_home(path); return
            if path == "/api/full-library/sync":
                self.app.sync_full_library(); self._redirect_home(path); return
            if path == "/api/full-library/auto-create":
                self.app.auto_create_full_channels(); self._redirect_home(path); return
            if path == "/api/full-library/suggestions/create":
                self.app.create_suggested_full_channel(form); self._redirect_home(path); return
            if path == "/api/full-library/channels":
                self.app.create_custom_full_channel(form); self._redirect_home(path); return
            if path == "/api/jellyfin/import":
                url = str(form.get("url") or "").strip()
                key = str(form.get("api_key") or "").strip()
                if not url or not key:
                    raise ValueError("Jellyfin URL and API key are required")
                JellyfinMetadataImporter(self.app.db).import_metadata(url, key)
                self.app.rebuild_schedules()
                self._redirect_home(path); return
            self._json(404, {"error": "Not found"})
        except (ValueError, MediaSafetyError, sqlite3.IntegrityError) as exc:
            self._json(400, {"error": str(exc)})
        except Exception as exc:
            self._json(500, {"error": f"Internal error: {exc}"})


def create_server(host: str, port: int, app: CableTVApplication) -> ThreadingHTTPServer:
    handler = type("CableTVHandler", (_Handler,), {"app": app})
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    return server


def run_from_env() -> None:
    data_dir = os.getenv("DATA_DIR", "/app/data")
    media_root = os.getenv("MEDIA_ROOT", "/media")
    tz_name = os.getenv("TZ", "UTC")
    allow_writable = os.getenv("ALLOW_WRITABLE_MEDIA", "0").strip().lower() in {"1", "true", "yes"}
    stream_mode = os.getenv("STREAM_MODE", "copy")
    public_base_url = os.getenv("PUBLIC_BASE_URL") or None
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8484"))
    app = CableTVApplication(data_dir, media_root, tz_name, allow_writable, stream_mode, public_base_url)
    server = create_server(host, port, app)
    print(f"Personal Cable TV v{__version__} listening on {host}:{port}")
    print(f"Media root: {media_root} | writable override: {allow_writable} | stream mode: {app.stream_mode}")

    def full_library_sync_loop():
        while True:
            try:
                app.run_due_full_sync_once()
                app.ensure_schedule_coverage()
            except Exception as exc:
                print(f"Background maintenance warning: {exc}")
            time.sleep(3600)

    threading.Thread(
        target=full_library_sync_loop, name="PersonalCableTVFullLibrarySync", daemon=True
    ).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    run_from_env()
