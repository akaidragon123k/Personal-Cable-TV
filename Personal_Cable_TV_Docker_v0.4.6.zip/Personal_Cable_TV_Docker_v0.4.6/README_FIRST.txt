PERSONAL CABLE TV v0.4.6 - SIMPLE DOCKER START
================================================

This package is for a NEW Docker install.
It does NOT contain anyone's database, API key, or media files.

START
1. Extract this folder anywhere you keep Docker apps.
2. Open a terminal in this folder.
3. Run:

   docker compose up -d --build

4. Open in a browser:

   http://YOUR-NAS-IP:8484

5. In Personal Cable TV, open Jellyfin and enter your Jellyfin URL + API key.

That is all that is required to start the app.

DATA
- Your Personal Cable TV database is stored in the local ./data folder.
- Keep ./data when updating or recreating the container.
- Do not share ./data on GitHub because it can contain your saved settings.

STOP
   docker compose down

START AGAIN
   docker compose up -d

STATUS
   docker compose ps

LOGS
   docker compose logs --tail=100 personal-cable-tv

DEFAULT PORT
8484

If 8484 is already used, create a .env file beside docker-compose.yml and add:
PCTV_PORT=8485

MEDIA SAFETY
- Full Library Mode talks to Jellyfin; it does not need your real media folders mounted into this container.
- This public Docker package does not mount /DATA, /, the Docker socket, or any real media folder.
- The container root filesystem is read-only; only ./data is writable app data.
